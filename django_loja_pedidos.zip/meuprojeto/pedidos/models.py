from django.db import models
from loja.models import Produto

class Pedido(models.Model):
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE)
    quantidade = models.PositiveIntegerField()
    data = models.DateTimeField(auto_now_add=True)

    def total(self):
        return self.produto.preco * self.quantidade

    def __str__(self):
        return f"Pedido de {self.quantidade}x {self.produto.nome}"
