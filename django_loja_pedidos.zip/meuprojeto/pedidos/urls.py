from django.urls import path
from . import views

urlpatterns = [
    path('pedido/<int:produto_id>/', views.criar_pedido, name='criar_pedido'),
]
