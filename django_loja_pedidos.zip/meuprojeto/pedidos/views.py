from django.shortcuts import render, redirect
from .models import Pedido
from loja.models import Produto

def criar_pedido(request, produto_id):
    produto = Produto.objects.get(id=produto_id)
    if request.method == 'POST':
        quantidade = int(request.POST.get('quantidade'))
        Pedido.objects.create(produto=produto, quantidade=quantidade)
        return redirect('lista_produtos')
    return render(request, 'pedidos/criar_pedido.html', {'produto': produto})
