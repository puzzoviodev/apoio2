Z3 – Projeto Django completo (todas as visões)
=================================================

Este pacote entrega um projeto Django com:
- App `fundamentus` (modelos, admin, migrations)
- Seeds: `load_sample_metrics` (mínimo) e `load_more_metrics` (ampliado)
- Templates para TODAS as telas que você enviou/planejou
- Página **Home** (form de ticker) e **Overview** por ativo com **links** para todas as visões
- Registro em `registry.py` para facilitar adicionar novas telas

Como rodar
---------
1) Crie e ative o venv; instale Django 4.x
   python -m venv .venv
   source .venv/bin/activate    # Windows: .venv\Scripts\activate
   pip install django

2) Migre e carregue dados
   python manage.py makemigrations
   python manage.py migrate
   python manage.py load_sample_metrics
   # (opcional – dataset completo)
   python manage.py load_more_metrics

3) Suba o servidor
   python manage.py runserver

4) Use
   - Home:               http://localhost:8000/fundamentus/
   - Overview (com links): http://localhost:8000/fundamentus/overview/ABEV3/

Telas disponíveis (exemplos)
----------------------------
- Flip 3D:                 /fundamentus/flip/ABEV3/
- Heatmap (filtro/busca):  /fundamentus/heatmap/?q=ABEV3
- QuickStats:              /fundamentus/quickstats/?ticker=ABEV3
- Comparador modal:        /fundamentus/compare/?a=ABEV3&b=AERI3
- Heatmap denso (tooltip): /fundamentus/heatmap/dense/?q=ABEV3
- Heatmap filtro+sort:     /fundamentus/heatmap/smart/?sort=valor&order=desc
- Tabela detalhada:        /fundamentus/table/?tickers=ABEV3
- Heatmap status:          /fundamentus/heatmap/status/?tickers=ABEV3

Adicionar novas telas
---------------------
1) Crie a view + template e exponha a rota em `fundamentus/urls.py`
2) Registre a tela em `fundamentus/registry.py` com `ViewEntry` e a função `build_url`
3) Ela aparecerá automaticamente na página Overview do ticker

Banco de dados
--------------
Usa SQLite (db.sqlite3). O arquivo é criado ao rodar `migrate`. Os comandos `load_*.py` populam ABEV3 e AERI3.
