# Generated for initial schema
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone

class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Company',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('ticker', models.CharField(max_length=16, unique=True)),
                ('name', models.CharField(blank=True, default='', max_length=128)),
            ],
        ),
        migrations.CreateModel(
            name='IndicatorDefinition',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.SlugField(max_length=64, unique=True)),
                ('label', models.CharField(max_length=64)),
                ('group', models.CharField(choices=[('Valuation', 'Valuation'), ('Rentabilidade', 'Rentabilidade'), ('Liquidez de Mercado', 'Liquidez de Mercado'), ('Liquidez', 'Liquidez'), ('Solvência', 'Solvência'), ('Estrutura de Capital', 'Estrutura de Capital'), ('Eficiência Operacional', 'Eficiência Operacional'), ('Governança Corporativa', 'Governança Corporativa'), ('Saúde Financeira', 'Saúde Financeira'), ('Outros', 'Outros')], default='Outros', max_length=32)),
                ('formula', models.TextField()),
                ('definition', models.TextField()),
                ('band', models.CharField(blank=True, default='', max_length=128)),
                ('reference', models.CharField(blank=True, default='', max_length=128)),
            ],
        ),
        migrations.CreateModel(
            name='IndicatorValue',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('value_raw', models.DecimalField(blank=True, decimal_places=8, max_digits=24, null=True)),
                ('value_display', models.CharField(blank=True, default='', max_length=64)),
                ('classification', models.CharField(choices=[('Ótimo', 'Ótimo'), ('Muito Bom', 'Muito Bom'), ('Bom', 'Bom'), ('Moderado', 'Moderado'), ('Ruim', 'Ruim'), ('Crítico', 'Crítico'), ('Muito Crítico', 'Muito Crítico')], max_length=16)),
                ('description', models.TextField(blank=True, default='')),
                ('source', models.CharField(blank=True, default='StausInvest', max_length=128)),
                ('updated_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('company', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='indicators', to='fundamentus.company')),
                ('indicator', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='values', to='fundamentus.indicatordefinition')),
            ],
            options={'unique_together': {('company', 'indicator')}},
        ),
    ]
