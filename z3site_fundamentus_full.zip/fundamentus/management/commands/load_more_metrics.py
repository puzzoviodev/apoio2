from decimal import Decimal
from django.core.management.base import BaseCommand
from fundamentus.models import Company, IndicatorDefinition, IndicatorValue, IndicatorGroup, Classification

DEF = lambda code, label, group, formula, definition, band: dict(code=code, label=label, group=group, formula=formula, definition=definition, band=band, reference="")

class Command(BaseCommand):
    help = 'Carrega conjunto ampliado para ABEV3 e AERI3 (muitas métricas).' 

    def handle(self, *args, **opts):
        abev3, _ = Company.objects.get_or_create(ticker='ABEV3', defaults={'name': 'Ambev S.A.'})
        aeri3, _ = Company.objects.get_or_create(ticker='AERI3', defaults={'name': 'Aeris Energy'})
        defs = [
            DEF('roic', 'ROIC', IndicatorGroup.RENTABILIDADE, 'ROIC (%) = (NOPAT/Capital Investido)*100', 'Retorno sobre o capital investido.', 'ROIC > 15%'),
            DEF('p_cap_giro', 'P/Cap. Giro', IndicatorGroup.VALUATION, 'VM/(AC-PC)', 'Preço sobre Capital de Giro.', 'P/Cap. Giro > 20'),
            DEF('dy', 'D.Y', IndicatorGroup.RENTABILIDADE, 'DY = (Div/Ação / Preço) * 100', 'Dividend Yield.', 'DY > 6%'),
            DEF('pl', 'P/L', IndicatorGroup.SAUDE, 'Preço/LPA', 'Preço sobre Lucro por Ação.', '—'),
            DEF('giro_ativos', 'Giro ativos', IndicatorGroup.EFICIENCIA, 'Receita/Ativos', 'Eficiência no uso do ativo.', '0.5 < x <= 1.0'),
            DEF('m_ebitda', 'M. EBITDA', IndicatorGroup.EFICIENCIA, 'EBITDA/Receita', 'Eficiência operacional.', '> 30%'),
            DEF('ev_ebitda', 'EV/EBITDA', IndicatorGroup.VALUATION, 'EV/EBITDA', 'Valuation vs EBITDA.', '4 < x <= 8'),
            DEF('roe', 'ROE', IndicatorGroup.RENTABILIDADE, 'Lucro/PL', 'Retorno sobre PL.', '15 < x <= 25%'),
            DEF('liq_md', 'LIQUIDEZ MEDIA DIARIA', IndicatorGroup.LIQUIDEZ_MERCADO, 'Volume/Dias', 'Liquidez média diária.', '> 2.000.000'),
            DEF('p_ebitda', 'P/EBITDA', IndicatorGroup.VALUATION, 'VM/EBITDA', 'Preço sobre EBITDA.', '0 <= x <= 6'),
            DEF('p_ativo', 'P/Ativo', IndicatorGroup.VALUATION, 'VM/Ativos', 'Preço sobre Ativos.', '1 < x <= 1.5'),
            DEF('liq_corr', 'Liq. corrente', IndicatorGroup.LIQUIDEZ, 'AC/PC', 'Liquidez Corrente.', '0.8 <= x < 1.2'),
            DEF('p_vp', 'P/VP', IndicatorGroup.VALUATION, 'Preço/VPA', 'Preço sobre VPA.', '1.8 < x <= 2.5'),
            DEF('ev_ebit', 'EV/EBIT', IndicatorGroup.VALUATION, 'EV/EBIT', 'Valuation vs EBIT.', '6 < x <= 10'),
            DEF('tag_along', 'TAG ALONG', IndicatorGroup.GOVERNANCA, '% garantido', 'Proteção minoritária.', '80%–100%'),
            DEF('m_bruta', 'M. Bruta', IndicatorGroup.EFICIENCIA, '(Receita-CPV)/Receita', 'Margem Bruta.', '40 < x <= 60%'),
            DEF('m_liquida', 'M. Liquida', IndicatorGroup.RENTABILIDADE, 'Lucro/Receita', 'Margem Líquida.', '15 < x <= 25%'),
            DEF('pl_ativos', 'PL/Ativos', IndicatorGroup.ESTRUTURA, 'PL/Ativos', 'Estrutura de capital.', '> 0.6'),
            DEF('div_liq_ebit', 'Div. liquida/EBIT', IndicatorGroup.SOLVENCIA, 'DL/EBIT', 'Solvência.', '< 0'),
            DEF('div_liq', 'Divida liquida', IndicatorGroup.OUTROS, 'DB - Caixa', 'Dívida líquida.', '< 0'),
            DEF('div_bruta', 'Divida bruta', IndicatorGroup.OUTROS, 'Total dívida', 'Dívida bruta.', '> 0'),
            DEF('div_liq_ebitda', 'Div. liquida/EBITDA', IndicatorGroup.SOLVENCIA, 'DL/EBITDA', 'Solvência.', '< 0'),
            DEF('roa', 'ROA', IndicatorGroup.RENTABILIDADE, 'Lucro/Ativos', 'Retorno sobre Ativos.', '7 < x <= 12%'),
            DEF('vpa', 'VPA', IndicatorGroup.VALUATION, 'PL/Nº ações', 'Valor patrimonial por ação.', '—'),
            DEF('p_ebit', 'P/EBIT', IndicatorGroup.VALUATION, 'VM/EBIT', 'Preço sobre EBIT.', '8 < x <= 12'),
            DEF('p_acl', 'P/Ativo Circ. Liq.', IndicatorGroup.VALUATION, 'VM/(AC-PC)', 'Preço sobre ACL.', '< 0'),
            DEF('lpa', 'LPA', IndicatorGroup.RENTABILIDADE, 'Lucro/Nº ações', 'Lucro por Ação.', '0 <= x <= 1'),
            DEF('psr', 'P/SR', IndicatorGroup.VALUATION, 'VM/Receita', 'Preço sobre Receita.', '2.0 < x <= 3.0'),
        ]
        defs_map = {}
        for d in defs:
            obj, _ = IndicatorDefinition.objects.get_or_create(code=d['code'], defaults=d)
            for f in ['label','group','formula','definition','band','reference']:
                setattr(obj, f, d[f])
            obj.save()
            defs_map[d['code']] = obj
        samples = [
            ('ABEV3','roic','0.1873','18,73%','Ótimo','Retorno muito alto.'),
            ('ABEV3','p_cap_giro','49.86','49,86','Ruim','Capital de giro caro.'),
            ('ABEV3','dy','8.48','8,48%','Ótimo','Dividendos robustos.'),
            ('ABEV3','pl','13.25','13,25','Ótimo','P/L confortável.'),
            ('ABEV3','giro_ativos','0.65','0,65','Moderado','Eficiência razoável.'),
            ('ABEV3','m_ebitda','0.3631','36,31%','Ótimo','Excelente margem EBITDA.'),
            ('ABEV3','ev_ebitda','5.45','5,45','Bom','Valuation equilibrado.'),
            ('ABEV3','roe','0.1595','15,95%','Bom','Bom ROE.'),
            ('ABEV3','liq_md','358014350.52','358.014.350,52','Ótimo','Alta liquidez de mercado.'),
            ('ABEV3','p_ebitda','5.88','5,88','Ótimo','Barato no P/EBITDA.'),
            ('ABEV3','p_ativo','1.37','1,37','Moderado','Preço/Ativo moderado.'),
            ('ABEV3','liq_corr','1.11','1,11','Moderado','Cobertura marginal.'),
            ('ABEV3','p_vp','2.11','2,11','Ruim','Acima do patrimonial.'),
            ('ABEV3','ev_ebit','7.88','7,88','Bom','Equilibrado.'),
            ('ABEV3','tag_along','0.8','80%','Moderado','Proteção padrão.'),
            ('ABEV3','m_bruta','0.515','51,5%','Bom','Margem bruta alta.'),
            ('ABEV3','m_liquida','0.1608','16,08%','Bom','Margem líquida boa.'),
            ('ABEV3','pl_ativos','0.65','0,65','Ótimo','Baixa alavancagem.'),
            ('ABEV3','div_liq_ebit','-0.63','-0,63','Ótimo','Caixa líquido/EBIT.'),
            ('ABEV3','div_liq','-14366814000.0','-14.366.814.000','Ótimo','Dívida líquida negativa.'),
            ('ABEV3','div_bruta','3157764000.0','3.157.764.000','Crítico','Dívida bruta alta.'),
            ('ABEV3','div_liq_ebitda','-0.43','-0,43','Ótimo','DL/EBITDA negativo.'),
            ('ABEV3','roa','0.1038','10,38%','Bom','Bom ROA.'),
            ('ABEV3','vpa','5.87','5,87','Crítico','VPA baixo vs preço.'),
            ('ABEV3','p_ebit','8.5','8,5','Bom','Equilibrado.'),
            ('ABEV3','p_acl','-1.93','-1,93','Crítico','AC líquido negativo.'),
            ('ABEV3','lpa','0.94','0,94','Ruim','LPA baixo.'),
            ('ABEV3','psr','2.13','2,13','Ruim','PSR elevado.'),
            ('AERI3','roic','-0.5822','-58,22%','Crítico','ROIC negativo.'),
            ('AERI3','p_cap_giro','1.15','1,15','Ótimo','P/Cap. Giro baixo.'),
            ('AERI3','dy','0.0','0,0%','Crítico','Sem dividendos.'),
            ('AERI3','pl','-0.22','-0,22','Crítico','PL negativo.'),
            ('AERI3','giro_ativos','0.5','0,5','Ruim','Baixa eficiência.'),
            ('AERI3','m_ebitda','-0.7154','-71,54%','Crítico','Margem EBITDA negativa.'),
            ('AERI3','ev_ebitda','-2.35','-2,35','Muito Crítico','EBITDA negativo.'),
            ('AERI3','roe','-18.2336','-18,2336%','Crítico','ROE negativo.'),
            ('AERI3','liq_md','548306.43','548.306,43','Bom','Liquidez razoável.'),
            ('AERI3','p_ebitda','-0.32','-0,32','Muito Crítico','P/EBITDA negativo.'),
            ('AERI3','p_ativo','0.12','0,12','Ótimo','Preço/Ativo muito baixo.'),
            ('AERI3','liq_corr','1.41','1,41','Bom','Boa liquidez corrente.'),
            ('AERI3','p_vp','-3.99','-3,99','Muito Crítico','P/VP negativo.'),
            ('AERI3','ev_ebit','-2.09','-2,09','Muito Crítico','EBIT negativo.'),
            ('AERI3','tag_along','1.0','100%','Ótimo','Proteção total.'),
            ('AERI3','m_bruta','0.0517','5,17%','Ruim','Margem bruta baixa.'),
            ('AERI3','m_liquida','-1.1232','-112,32%','Crítico','Margem líquida negativa.'),
            ('AERI3','pl_ativos','-0.03','-0,03','Crítico','PL/Ativos negativo.'),
            ('AERI3','div_liq_ebit','-1.81','-1,81','Ótimo','Caixa líquido/EBIT.'),
            ('AERI3','div_liq','1626181000.0','1.626.181.000','Ruim','Dívida líquida alta.'),
            ('AERI3','div_bruta','1693749000.0','1.693.749.000','Crítico','Dívida bruta alta.'),
            ('AERI3','div_liq_ebitda','-2.2','-2,2','Ótimo','DL/EBITDA negativo.'),
            ('AERI3','roa','-0.5667','-56,67%','Crítico','ROA negativo.'),
            ('AERI3','vpa','-1.02','-1,02','Muito Crítico','VPA negativo.'),
            ('AERI3','p_ebit','-0.28','-0,28','Muito Crítico','P/EBIT negativo.'),
            ('AERI3','p_acl','-0.2','-0,2','Crítico','AC líquido negativo.'),
            ('AERI3','lpa','-18.65','-18,65','Crítico','LPA negativo.'),
            ('AERI3','psr','0.25','0,25','Ótimo','PSR muito baixo.'),
        ]
        from decimal import Decimal
        for t, code, raw, disp, klass, desc in samples:
            comp = Company.objects.get(ticker=t)
            ind = IndicatorDefinition.objects.get(code=code)
            IndicatorValue.objects.update_or_create(
                company=comp, indicator=ind,
                defaults=dict(value_raw=Decimal(raw), value_display=disp, classification=klass, description=desc, source='StausInvest')
            )
        self.stdout.write(self.style.SUCCESS('Conjunto ampliado carregado.'))
