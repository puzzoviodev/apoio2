from dataclasses import dataclass
from typing import Callable, Optional

@dataclass
class ViewEntry:
    key: str
    name: str
    desc: str
    build_url: Callable[[str, Optional[str]], str]

# Register here to expose in the overview page
ENTRIES = [
    ViewEntry(
        key="flip",
        name="Flip 3D por Ativo",
        desc="Cards 3D com frente/verso por indicador",
        build_url=lambda t, u: f"/fundamentus/flip/{t}/",
    ),
    ViewEntry(
        key="heatmap_filter",
        name="Heatmap (Filtro & Busca)",
        desc="Busca por ticker/indicador e filtro por classificação",
        build_url=lambda t, u: f"/fundamentus/heatmap/?q={t}",
    ),
    ViewEntry(
        key="quickstats",
        name="QuickStats",
        desc="Contagem por classificação e por empresa",
        build_url=lambda t, u: f"/fundamentus/quickstats/?ticker={t}",
    ),
    ViewEntry(
        key="modal_compare",
        name="Comparador com Modal (A × B)",
        desc="Clique no card para abrir modal e ver os dois lado a lado",
        build_url=lambda t, u: f"/fundamentus/compare/?a={t}&b={u or 'AERI3'}",
    ),
    ViewEntry(
        key="heatmap_dense",
        name="Heatmap Denso (Tooltip)",
        desc="Tooltip com fórmula, definição, faixa e referência",
        build_url=lambda t, u: f"/fundamentus/heatmap/dense/?q={t}",
    ),
    ViewEntry(
        key="heatmap_smart",
        name="Heatmap Filtro + Ordenação",
        desc="Chips por classificação e ordenação por indicador/ticker/valor",
        build_url=lambda t, u: f"/fundamentus/heatmap/smart/?sort=valor&order=desc",
    ),
    ViewEntry(
        key="table",
        name="Tabela Detalhada",
        desc="Indicador | Valor | Status | Categoria | Faixa | Resumo",
        build_url=lambda t, u: f"/fundamentus/table/?tickers={t}",
    ),
    ViewEntry(
        key="status_heatmap",
        name="Heatmap de Status por Categoria",
        desc="Cor por estado (Crítico → Ótimo)",
        build_url=lambda t, u: f"/fundamentus/heatmap/status/?tickers={t}",
    ),
]
