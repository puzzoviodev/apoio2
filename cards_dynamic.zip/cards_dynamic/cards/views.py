from django.views.generic import ListView, DetailView
from .models import Company

class CompanyListView(ListView):
    model = Company
    template_name = 'cards/company_list.html'
    context_object_name = 'companies'

class CompanyDetailView(DetailView):
    model = Company
    template_name = 'cards/company_detail.html'
    context_object_name = 'company'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['cards'] = self.object.cards.all()
        return ctx
