from django.core.management.base import BaseCommand, CommandError
from cards.models import Company, Card
import re

class Command(BaseCommand):
    help = 'Importa cartões a partir de um arquivo de texto/HTML exportado (Ex2 Cards Grid)'

    def add_arguments(self, parser):
        parser.add_argument('path', type=str, help='Caminho do arquivo fonte (ex.: seed/ex2_cards_grid_from_excel.html)')

    def handle(self, *args, **opts):
        path = opts['path']
        try:
            raw = open(path, 'r', encoding='utf-8').read()
        except Exception as e:
            raise CommandError(f'Erro lendo {path}: {e}')

        # Estratégia de parsing simples baseada nos padrões do arquivo
        # 1) Split por seções de Ativo: lines como '### Ativo: TICKER'
        sections = re.split(r"^###\s+Ativo:\s*(.+?)\s*$", raw, flags=re.M|re.U)
        # re.split devolve [head, ticker1, body1, ticker2, body2, ...]
        if len(sections) < 3:
            self.stdout.write(self.style.WARNING('Nenhuma seção de Ativo encontrada.'))
            return

        created_companies = 0
        created_cards = 0
        status_map = {
            'Ótimo':'OTIMO','Muito Bom':'MUITO_BOM','Bom':'BOM','Moderado':'MODERADO',
            'Ruim':'RUIM','Crítico':'CRITICO','Muito Crítico':'MUITO_CRITICO'
        }

        for i in range(1, len(sections), 2):
            ticker = sections[i].strip()
            body = sections[i+1]

            comp, _ = Company.objects.get_or_create(ticker=ticker)
            created_companies += 1

            # Cards: padrão aproximado — status line, title (#### ...), value, category/source, Faixa, summary, Detalhes, Fórmula, Definição
            lines = [l.strip() for l in body.splitlines()]
            order = 1
            j = 0
            while j < len(lines):
                line = lines[j]
                if line in status_map:  # status
                    status_code = status_map[line]
                    # title
                    title = ''
                    value = ''
                    category = ''
                    source = ''
                    range_text = ''
                    summary = ''
                    formula = ''
                    definition = ''
                    # expect next lines pattern
                    if j+1 < len(lines) and lines[j+1].startswith('#### '):
                        title = lines[j+1][5:].strip()
                        j += 2
                    else:
                        j += 1
                        continue
                    # value
                    if j < len(lines) and lines[j]:
                        value = lines[j]
                        j += 1
                    # category • Fonte
                    if j < len(lines) and '•' in lines[j]:
                        parts = [p.strip() for p in lines[j].split('•')]
                        if parts:
                            category = parts[0]
                        if len(parts) > 1 and 'Fonte:' in parts[1]:
                            source = parts[1].replace('Fonte:', '').strip()
                        j += 1
                    # Faixa
                    if j < len(lines) and lines[j].startswith('Faixa:'):
                        range_text = lines[j].replace('Faixa:', '').strip()
                        j += 1
                    # summary (até linha "Detalhes" ou próximo status)
                    summary_lines = []
                    while j < len(lines) and lines[j] not in status_map and not lines[j].startswith('Detalhes'):
                        if lines[j]:
                            summary_lines.append(lines[j])
                        j += 1
                    summary = ' '.join(summary_lines).strip()
                    # Detalhes
                    if j < len(lines) and lines[j].startswith('Detalhes'):
                        j += 1
                        # Fórmula
                        if j < len(lines) and lines[j].startswith('Fórmula:'):
                            formula = lines[j].replace('Fórmula:', '').strip()
                            j += 1
                        # Definição
                        if j < len(lines) and lines[j].startswith('Definição:'):
                            definition = lines[j].replace('Definição:', '').strip()
                            j += 1
                    # Persist
                    Card.objects.create(
                        company=comp, status=status_code, title=title, value=value,
                        category=category, source=source, range_text=range_text,
                        summary=summary, formula=formula, definition=definition,
                        order=order
                    )
                    order += 1
                    created_cards += 1
                else:
                    j += 1

            comp.total_cards = comp.cards.count()
            comp.save()

        self.stdout.write(self.style.SUCCESS(f'Importação concluída. Empresas: {created_companies}, Cartões: {created_cards}'))
