from django.contrib import admin
from .models import Company, Card

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('ticker','total_cards')

@admin.register(Card)
class CardAdmin(admin.ModelAdmin):
    list_display = ('company','order','status','title','value','category')
    list_filter = ('company','status','category')
    search_fields = ('title','summary','formula','definition')
