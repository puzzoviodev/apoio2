from django.db import models

class Company(models.Model):
    ticker = models.CharField(max_length=20, unique=True)
    total_cards = models.PositiveIntegerField(default=0)
    def __str__(self):
        return self.ticker

class Card(models.Model):
    STATUS_CHOICES = [
        ('OTIMO','Ótimo'),('MUITO_BOM','Muito Bom'),('BOM','Bom'),('MODERADO','Moderado'),
        ('RUIM','Ruim'),('CRITICO','Crítico'),('MUITO_CRITICO','Muito Crítico')
    ]
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='cards')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    title = models.CharField(max_length=120)
    value = models.CharField(max_length=60)
    category = models.CharField(max_length=80, blank=True)
    source = models.CharField(max_length=120, blank=True)
    range_text = models.CharField(max_length=200, blank=True)
    summary = models.TextField(blank=True)
    formula = models.TextField(blank=True)
    definition = models.TextField(blank=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['company','order']
