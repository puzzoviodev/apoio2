# cards_dynamic — versão dinâmica com SQLite

## Rodar
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python manage.py migrate
# importar do arquivo incluído em seed/
python manage.py import_cards seed/ex2_cards_grid_from_excel.html
python manage.py runserver
```

Abra http://127.0.0.1:8000 — clique em um ticker para ver os cartões.
