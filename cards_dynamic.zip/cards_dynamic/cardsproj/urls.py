from django.contrib import admin
from django.urls import path
from cards.views import CompanyListView, CompanyDetailView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', CompanyListView.as_view(), name='home'),
    path('company/<int:pk>/', CompanyDetailView.as_view(), name='company_detail'),
]
