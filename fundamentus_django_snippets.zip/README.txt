Como usar
=========
1) Adicione 'fundamentus' ao INSTALLED_APPS do seu settings.py.
2) Inclua as URLs no yourproject/urls.py:
    path('fundamentus/', include('fundamentus.urls'))
3) Migre e carregue amostras:
    python manage.py makemigrations fundamentus
    python manage.py migrate
    python manage.py load_sample_metrics
4) Rode o servidor e acesse:
    /fundamentus/flip/ABEV3/
    /fundamentus/heatmap/
    /fundamentus/quickstats/
