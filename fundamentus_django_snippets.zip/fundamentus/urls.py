from django.urls import path
from . import views

app_name = "fundamentus"

urlpatterns = [
    path("flip/<str:ticker>/", views.flip_cards_3d, name="flip"),
    path("heatmap/", views.filter_togglecard, name="heatmap"),
    path("quickstats/", views.quickstats, name="quickstats"),
]
