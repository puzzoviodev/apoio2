
# Status Cards (Django)

Projeto Django gerado automaticamente a partir de HTML com grid de indicadores.

## Rodar
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata indicadores/fixtures/indicadores.json  # opcional
python manage.py runserver
```

## Importar vários HTMLs
```bash
python manage.py importar_html pasta_ou_arquivos --clear  # reimporta do zero
python manage.py importar_html a.html b.html c.html       # upsert
```
- Deduplicação por `(ativo, nome)`.
- CSS preservado em `indicadores/static/indicadores/css/style.css`.
