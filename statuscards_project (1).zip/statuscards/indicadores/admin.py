
from django.contrib import admin
from .models import Ativo, Indicador
@admin.register(Ativo)
class AtivoAdmin(admin.ModelAdmin):
    search_fields=['ticker']
@admin.register(Indicador)
class IndicadorAdmin(admin.ModelAdmin):
    list_display=['ativo','nome','status','valor_texto','categoria']
    list_filter=['status','categoria','ativo']
    search_fields=['nome','analise','faixa','formula','definicao']
