
from django.apps import AppConfig
class IndicadoresConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'
    name='indicadores'
    verbose_name='Indicadores (Cards)'
