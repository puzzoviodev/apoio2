
from django.core.management.base import BaseCommand, CommandError
from indicadores.models import Ativo, Indicador
import re, os

class Command(BaseCommand):
    help = ("Importa um ou mais arquivos HTML com grid de cards para o banco.
"
            "Uso: python manage.py importar_html caminho/arquivo1.html [arquivo2.html ...] [--clear]")

    def add_arguments(self, parser):
        parser.add_argument('paths', nargs='+', help='Arquivos ou pastas com .html')
        parser.add_argument('--clear', action='store_true', help='Apaga Indicadores antes de importar')

    def handle(self, *args, **opts):
        paths = opts['paths']
        clear = opts['clear']

        html_files = []
        for p in paths:
            if os.path.isdir(p):
                for nome in os.listdir(p):
                    if nome.lower().endswith('.html'):
                        html_files.append(os.path.join(p, nome))
            elif p.lower().endswith('.html'):
                html_files.append(p)
        if not html_files:
            raise CommandError('Nenhum .html encontrado.')

        if clear:
            self.stdout.write(self.style.WARNING('Limpando Indicadores (mantendo Ativos)...'))
            Indicador.objects.all().delete()

        ativo_pat = re.compile(r'<h2\s+class="section-title">\s*Ativo:\s*([A-Z0-9\.]+)\s*<small', re.MULTILINE)
        section_pat = re.compile(r'<section\s+class="grid">(.*?)</section>', re.DOTALL)
        card_pat = re.compile(r'<article\s+class="card">(.*?)</article>', re.DOTALL)

        total_cards = 0
        ativos_set = set()

        def rex(pat, h):
            m = re.search(pat, h, re.DOTALL)
            return m.group(1).strip() if m else ''

        for f in html_files:
            with open(f, 'r', encoding='utf-8') as fh:
                html = fh.read()
            headers = list(ativo_pat.finditer(html))
            if not headers:
                self.stdout.write(self.style.WARNING(f"[AVISO] Nenhum 'Ativo:' em {f}"))
                continue
            for idx, m in enumerate(headers):
                ticker = m.group(1)
                ativos_set.add(ticker)
                start_pos = m.end()
                end_pos = headers[idx+1].start() if idx+1 < len(headers) else len(html)
                sec_m = section_pat.search(html[start_pos:end_pos])
                if not sec_m:
                    self.stdout.write(self.style.WARNING(f"Sem <section class='grid'> para {ticker} em {f}"))
                    continue
                grid = sec_m.group(1)
                ativo, _ = Ativo.objects.get_or_create(ticker=ticker)
                for cm in card_pat.finditer(grid):
                    ch = cm.group(1)
                    status = rex(r'<span\s+class="chip[^>]*">\s*(.*?)\s*</span>', ch) or 'Moderado'
                    nome = rex(r'<h3\s+class="card__titulo">\s*(.*?)\s*</h3>', ch)
                    if not nome:
                        continue
                    valor = rex(r'<p\s+class="card__valor">\s*(.*?)\s*</p>', ch)
                    nota = rex(r'<p\s+class="card__nota">\s*(.*?)\s*</p>', ch)
                    categoria, fonte = '', ''
                    if '•' in nota and 'Fonte' in nota:
                        parts = [p.strip() for p in nota.split('•')]
                        categoria = parts[0]
                        fonte_part = parts[1]
                        fonte = fonte_part.split(':',1)[1].strip() if ':' in fonte_part else fonte_part
                    else:
                        categoria = nota
                    faixa = rex(r'<p\s+class="card__faixa">\s*<strong>Faixa:</strong>\s*(.*?)\s*</p>', ch)
                    analise = rex(r'<p\s+class="card__desc">\s*(.*?)\s*</p>', ch)
                    formula = rex(r'<strong>Fórmula:</strong>\s*(.*?)\s*</p>', ch)
                    definicao = rex(r'<strong>Definição:</strong>\s*(.*?)\s*</p>', ch)

                    # UPSERT (ativo, nome)
                    Indicador.objects.update_or_create(
                        ativo=ativo, nome=nome,
                        defaults={
                            'status': status,
                            'valor_texto': valor,
                            'categoria': categoria,
                            'fonte': fonte,
                            'faixa': faixa,
                            'analise': ' '.join(analise.split()),
                            'formula': ' '.join(formula.split()),
                            'definicao': ' '.join(definicao.split()),
                        }
                    )
                    total_cards += 1

        self.stdout.write(self.style.SUCCESS(
            f"Importação concluída: {total_cards} cards, {len(ativos_set)} ativos (upsert por (ativo,nome))."
        ))
