Trinca 2: Compare/Tooltip/Filter+Sort
=====================================
Rotas adicionadas:
  - /fundamentus/compare/?a=ABEV3&b=AERI3
  - /fundamentus/heatmap/dense/
  - /fundamentus/heatmap/smart/?class=Ótimo&sort=valor&order=desc

Como usar:
  1) Adicione 'fundamentus' ao INSTALLED_APPS
  2) Inclua as URLs no yourproject/urls.py
  3) Migre o app (se necessário) e rode o seed desta trinca:
        python manage.py load_more_metrics

Observação: Os estilos seguem o mesmo layout base dos exemplos anteriores, com ajustes mínimos.
