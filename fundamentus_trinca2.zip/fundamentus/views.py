from django.db.models import Count
from django.db import models
from django.shortcuts import get_object_or_404, render
from django.http import HttpRequest, HttpResponse
from .models import Company, IndicatorValue, Classification


# === Views já existentes (exemplo) ===

def flip_cards_3d(request: HttpRequest, ticker: str) -> HttpResponse:
    company = get_object_or_404(Company, ticker__iexact=ticker)
    values = (
        IndicatorValue.objects.select_related("indicator", "company")
        .filter(company=company)
        .order_by("indicator__group", "indicator__label")
    )
    return render(request, "fundamentus/flip_cards_3d.html", {"company": company, "values": values})


def filter_togglecard(request: HttpRequest) -> HttpResponse:
    q = (request.GET.get("q") or "").strip()
    klass = (request.GET.get("class") or "").strip()
    queryset = IndicatorValue.objects.select_related("indicator", "company")
    if q:
        queryset = queryset.filter(
            models.Q(company__ticker__icontains=q)
            | models.Q(indicator__label__icontains=q)
            | models.Q(indicator__code__icontains=q)
        )
    if klass in dict(Classification.choices):
        queryset = queryset.filter(classification=klass)
    queryset = queryset.order_by("company__ticker", "indicator__group", "indicator__label")
    classes = [c[0] for c in Classification.choices]
    return render(request, "fundamentus/filter_togglecard.html", {"values": queryset, "q": q, "klass": klass, "classes": classes})


def quickstats(request: HttpRequest) -> HttpResponse:
    ticker = (request.GET.get("ticker") or "").strip()
    base_qs = IndicatorValue.objects.select_related("company")
    if ticker:
        base_qs = base_qs.filter(company__ticker__iexact=ticker)
    by_class = base_qs.values("classification").annotate(total=Count("id")).order_by("classification")
    by_company = base_qs.values("company__ticker").annotate(total=Count("id")).order_by("company__ticker")
    return render(request, "fundamentus/quickstats.html", {
        "ticker": ticker,
        "by_class": by_class,
        "by_company": by_company,
        "all_classes": [c[0] for c in Classification.choices],
    })


# === Novas Views (trinca 2/3) ===


def modal_compare(request: HttpRequest) -> HttpResponse:
    """Modal de comparação entre dois tickers.
    Params: ?a=ABEV3&b=AERI3
    Renderiza cartões por indicador; ao clicar, abre modal exibindo ambos lado a lado.
    """
    t_a = (request.GET.get("a") or "ABEV3").strip()
    t_b = (request.GET.get("b") or "AERI3").strip()

    a = Company.objects.filter(ticker__iexact=t_a).first()
    b = Company.objects.filter(ticker__iexact=t_b).first()

    vals = (
        IndicatorValue.objects.select_related("indicator", "company")
        .filter(company__ticker__in=[t_a, t_b])
        .order_by("indicator__group", "indicator__label", "company__ticker")
    )
    # Agrupa por indicador para facilitar exibição lado a lado
    grouped = {}
    for iv in vals:
        key = (iv.indicator.group, iv.indicator.label, iv.indicator.code)
        grouped.setdefault(key, {"a": None, "b": None, "def": iv.indicator})
        if iv.company.ticker.upper() == t_a.upper():
            grouped[key]["a"] = iv
        elif iv.company.ticker.upper() == t_b.upper():
            grouped[key]["b"] = iv

    context = {
        "ticker_a": t_a.upper(),
        "ticker_b": t_b.upper(),
        "company_a": a,
        "company_b": b,
        "grouped": grouped,
    }
    return render(request, "fundamentus/hfm02_modal_compare.html", context)


def heatmap_dense_tooltip(request: HttpRequest) -> HttpResponse:
    """Heatmap denso com tooltip com TODOS os campos do indicador/definição."""
    q = (request.GET.get("q") or "").strip()
    klass = (request.GET.get("class") or "").strip()
    queryset = IndicatorValue.objects.select_related("indicator", "company")
    if q:
        queryset = queryset.filter(
            models.Q(company__ticker__icontains=q)
            | models.Q(indicator__label__icontains=q)
            | models.Q(indicator__code__icontains=q)
        )
    if klass in dict(Classification.choices):
        queryset = queryset.filter(classification=klass)
    queryset = queryset.order_by("company__ticker", "indicator__group", "indicator__label")
    classes = [c[0] for c in Classification.choices]
    return render(request, "fundamentus/hm03_dense_tooltip.html", {"values": queryset, "q": q, "klass": klass, "classes": classes})


def heatmap_filter_sort(request: HttpRequest) -> HttpResponse:
    """Heatmap com filtros por classe (chips) e ordenação por label, ticker ou valor."""
    klass = (request.GET.get("class") or "").strip()
    sort = (request.GET.get("sort") or "label").strip() # label|ticker|valor
    order = (request.GET.get("order") or "asc").strip()

    qs = IndicatorValue.objects.select_related("indicator", "company")
    if klass in dict(Classification.choices):
        qs = qs.filter(classification=klass)

    if sort == "ticker":
        order_by = "company__ticker"
    elif sort == "valor":
        # Usa value_raw quando existir; fallback label
        order_by = "value_raw"
    else:
        order_by = "indicator__label"

    if order == "desc":
        order_by = f"-{order_by}"

    qs = qs.order_by(order_by, "indicator__group", "company__ticker")

    return render(request, "fundamentus/hm05_filter_sort.html", {
        "values": qs,
        "klass": klass,
        "sort": sort,
        "order": order,
        "classes": [c[0] for c in Classification.choices],
    })
