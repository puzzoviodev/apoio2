from django.db import models
from django.utils import timezone


class Classification(models.TextChoices):
    OTIMO = "Ótimo", "Ótimo"
    MUITO_BOM = "Muito Bom", "Muito Bom"
    BOM = "Bom", "Bom"
    MODERADO = "Moderado", "Moderado"
    RUIM = "Ruim", "Ruim"
    CRITICO = "Crítico", "Crítico"
    MUITO_CRITICO = "Muito Crítico", "Muito Crítico"


class Company(models.Model):
    ticker = models.CharField(max_length=16, unique=True)
    name = models.CharField(max_length=128, blank=True, default="")

    def __str__(self) -> str:
        return self.ticker


class IndicatorGroup(models.TextChoices):
    VALUATION = "Valuation", "Valuation"
    RENTABILIDADE = "Rentabilidade", "Rentabilidade"
    LIQUIDEZ_MERCADO = "Liquidez de Mercado", "Liquidez de Mercado"
    LIQUIDEZ = "Liquidez", "Liquidez"
    SOLVENCIA = "Solvência", "Solvência"
    ESTRUTURA = "Estrutura de Capital", "Estrutura de Capital"
    EFICIENCIA = "Eficiência Operacional", "Eficiência Operacional"
    GOVERNANCA = "Governança Corporativa", "Governança Corporativa"
    SAUDE = "Saúde Financeira", "Saúde Financeira"
    OUTROS = "Outros", "Outros"


class IndicatorDefinition(models.Model):
    code = models.SlugField(max_length=64, unique=True)
    label = models.CharField(max_length=64)
    group = models.CharField(max_length=32, choices=IndicatorGroup.choices, default=IndicatorGroup.OUTROS)
    formula = models.TextField()
    definition = models.TextField()
    band = models.CharField(max_length=128, blank=True, default="")
    reference = models.CharField(max_length=128, blank=True, default="")

    def __str__(self) -> str:
        return f"{self.label} ({self.code})"


class IndicatorValue(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name="indicators")
    indicator = models.ForeignKey(IndicatorDefinition, on_delete=models.CASCADE, related_name="values")
    value_raw = models.DecimalField(max_digits=24, decimal_places=8, null=True, blank=True)
    value_display = models.CharField(max_length=64, blank=True, default="")
    classification = models.CharField(max_length=16, choices=Classification.choices)
    description = models.TextField(blank=True, default="")
    source = models.CharField(max_length=128, blank=True, default="StausInvest")
    updated_at = models.DateTimeField(default=timezone.now)

    class Meta:
        unique_together = ("company", "indicator")

    def __str__(self) -> str:
        return f"{self.company} - {self.indicator.label}: {self.value_display or self.value_raw} ({self.classification})"
