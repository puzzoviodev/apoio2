from django.urls import path
from . import views

app_name = "fundamentus"

urlpatterns = [
    # anteriores
    path("flip/<str:ticker>/", views.flip_cards_3d, name="flip"),
    path("heatmap/", views.filter_togglecard, name="heatmap"),
    path("quickstats/", views.quickstats, name="quickstats"),
    # novos
    path("compare/", views.modal_compare, name="modal_compare"),
    path("heatmap/dense/", views.heatmap_dense_tooltip, name="heatmap_dense"),
    path("heatmap/smart/", views.heatmap_filter_sort, name="heatmap_filter_sort"),
]
