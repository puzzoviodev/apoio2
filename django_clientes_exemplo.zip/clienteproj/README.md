
# Exemplo Django + SQLite: Pesquisa por CNPJ

Projeto simples com 2 telas: uma de **pesquisa por CNPJ** e uma **grid** com os resultados.

## Campos do modelo `Cliente`
- ID (chave primária padrão)
- nome
- endereço
- profissão
- cep
- cnpj

Consulte `Guia_Projeto_Django_Clientes.docx` para o passo a passo completo.
