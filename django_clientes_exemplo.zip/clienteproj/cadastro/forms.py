
from django import forms
import re

class CNPJSearchForm(forms.Form):
    cnpj = forms.CharField(label='CNPJ', max_length=18, required=True,
                           widget=forms.TextInput(attrs={'placeholder': 'Digite o CNPJ', 'class': 'form-control'}))

    def clean_cnpj(self):
        value = self.cleaned_data['cnpj']
        # Remove tudo que não for dígito
        digits = re.sub(r"\D+", "", value)
        if len(digits) < 8:
            raise forms.ValidationError('Informe ao menos 8 dígitos para pesquisar.')
        return digits
