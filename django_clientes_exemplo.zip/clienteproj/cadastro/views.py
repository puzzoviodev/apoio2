
from django.shortcuts import render, redirect
from .forms import CNPJSearchForm
from .models import Cliente

def pesquisa_cnpj(request):
    if request.method == 'POST':
        form = CNPJSearchForm(request.POST)
        if form.is_valid():
            cnpj = form.cleaned_data['cnpj']
            return redirect('resultado', cnpj=cnpj)
    else:
        form = CNPJSearchForm()
    return render(request, 'cadastro/search.html', {'form': form})

def resultado_grid(request, cnpj):
    # Busca flexível contendo os dígitos informados
    clientes = Cliente.objects.filter(cnpj__icontains=cnpj)
    contexto = {
        'cnpj_consultado': cnpj,
        'clientes': clientes,
        'total': clientes.count(),
    }
    return render(request, 'cadastro/results.html', contexto)
