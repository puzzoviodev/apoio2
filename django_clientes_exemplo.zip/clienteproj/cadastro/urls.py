
from django.urls import path
from . import views

urlpatterns = [
    path('', views.pesquisa_cnpj, name='pesquisa'),
    path('resultado/<str:cnpj>/', views.resultado_grid, name='resultado'),
]
