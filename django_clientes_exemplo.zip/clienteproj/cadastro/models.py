
from django.db import models

class Cliente(models.Model):
    nome = models.CharField('Nome', max_length=150)
    endereco = models.CharField('Endereço', max_length=255)
    profissao = models.CharField('Profissão', max_length=100)
    cep = models.CharField('CEP', max_length=9, help_text='Formato: 00000-000')
    cnpj = models.CharField('CNPJ', max_length=18, help_text='Formato: 00.000.000/0000-00')

    def __str__(self):
        return f"{self.nome} ({self.cnpj})"

    class Meta:
        verbose_name = 'Cliente'
        verbose_name_plural = 'Clientes'
        ordering = ['nome']
