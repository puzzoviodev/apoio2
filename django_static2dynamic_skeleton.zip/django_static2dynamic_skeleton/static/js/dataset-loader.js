
// dataset-loader.js
// Carrega o dataset da API e expõe AT/RAW no escopo global.
// Se window.initPage existir, chama após o carregamento.

async function loadDataset(url){
  try{
    const resp = await fetch(url);
    if(!resp.ok) throw new Error('Falha no fetch do dataset: ' + resp.status);
    const DS = await resp.json();
    window.AT = DS.ativo_col || 'Ativo';
    window.RAW = DS.data || [];
    if(typeof window.initPage === 'function'){
      window.initPage();
    }
  }catch(err){
    console.error(err);
    const host = document.getElementById('wrap') || document.body;
    const div = document.createElement('div');
    div.className = 'small';
    div.textContent = 'Erro ao carregar dados: ' + (err.message || err);
    host.appendChild(div);
  }
}
