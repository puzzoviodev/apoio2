
from django.contrib import admin
from django.urls import path
from core.views import dataset_json, page_by_name_fetch, page_by_name_ssr

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/dataset', dataset_json, name='dataset_json'),
    path('page/<slug:name>/', page_by_name_fetch, name='page_by_name_fetch'),
    path('page-ssr/<slug:name>/', page_by_name_ssr, name='page_by_name_ssr'),
]
