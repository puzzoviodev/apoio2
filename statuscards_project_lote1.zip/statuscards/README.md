
# Status Cards (Django)

Projeto Django gerado automaticamente a partir de vários layouts HTML (grid, horizontais, mosaico), preservando o layout nos templates.

## Rodar
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata indicadores/fixtures/indicadores.json  # dados importados destes 3 HTMLs
python manage.py runserver
```

## Páginas
- `/` — Home (ativos)
- `/ativo/<TICKER>/` — Grid por ativo (Ex2)
- `/horizontais/` — Ex9 – Cards Horizontais
- `/mosaico/` — Layout C – Mosaico por Classificação
- `/lista/` — Ex3 – Lista com Filtros

## Importar mais HTMLs
```bash
python manage.py importar_html pasta_ou_arquivos --clear  # reimporta
python manage.py importar_html arquivo1.html arquivo2.html # upsert
```
