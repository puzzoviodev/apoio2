
from django.core.management.base import BaseCommand, CommandError
from indicadores.models import Ativo, Indicador
import re, os

class Command(BaseCommand):
    help = ("Importa um ou mais arquivos HTML com indicadores (layouts: grid, horizontais, mosaico).
"
            "Uso: python manage.py importar_html caminho/arquivo1.html [arquivo2.html ...] [--clear]")

    def add_arguments(self, parser):
        parser.add_argument('paths', nargs='+', help='Arquivos ou pastas com .html')
        parser.add_argument('--clear', action='store_true', help='Apaga Indicadores antes de importar')

    def handle(self, *args, **opts):
        paths = opts['paths']
        clear = opts['clear']

        html_files = []
        for p in paths:
            if os.path.isdir(p):
                for nome in os.listdir(p):
                    if nome.lower().endswith('.html'):
                        html_files.append(os.path.join(p, nome))
            elif p.lower().endswith('.html'):
                html_files.append(p)
        if not html_files:
            raise CommandError('Nenhum .html encontrado.')

        if clear:
            self.stdout.write(self.style.WARNING('Limpando Indicadores (mantendo Ativos)...'))
            Indicador.objects.all().delete()

        # Regex helpers
        ativo_pat = re.compile(r'<h2\s+class="section-title">\s*Ativo:\s*([A-Z0-9\.]+)\s*<small', re.MULTILINE)
        section_pat = re.compile(r'<section\s+class="grid">(.*?)</section>', re.DOTALL)
        card_pat = re.compile(r'<article\s+class="card">(.*?)</article>', re.DOTALL)

        def rex(pat, h):
            m = re.search(pat, h, re.DOTALL)
            return m.group(1).strip() if m else ''

        total = 0
        for f in html_files:
            with open(f, 'r', encoding='utf-8') as fh:
                html = fh.read()

            # Try EX9-like blocks first (Agrupador)
            if 'Agrupador:' in html:
                blocks = re.split(r'
###\s*Agrupador:\s*', html)
                for blk in blocks[1:]:
                    lines = blk.splitlines()
                    categoria = lines[0].strip()
                    i = 1
                    while i < len(lines):
                        if lines[i].strip().startswith('####'):
                            nome = lines[i].strip().lstrip('#').strip()
                            i += 1
                            while i < len(lines) and lines[i].strip() == '': i += 1
                            if i>=len(lines): break
                            valor = lines[i].strip(); i += 1
                            status_line = lines[i].strip() if i < len(lines) else ''
                            sm = re.match(r'([^ ]+)\s+Ativo:\s*([A-Z0-9\.]+)(.*)', status_line)
                            status, ticker, fonte, faixa = '', '', '', ''
                            if sm:
                                status, ticker, rest = sm.group(1), sm.group(2), sm.group(3)
                                fm = re.search(r'Fonte:\s*([^F
]+)', rest)
                                if fm: fonte = fm.group(1).strip()
                                fa = re.search(r'Faixa:\s*(.*)$', rest)
                                if fa: faixa = fa.group(1).strip()
                            # Advance to collect analise + detalhes
                            i += 1
                            anal_lines = []
                            while i < len(lines) and lines[i].strip() not in ('Detalhes',) and not lines[i].startswith('####'):
                                if lines[i].strip(): anal_lines.append(lines[i].strip())
                                i += 1
                            analise = ' '.join(anal_lines).strip()
                            formula = definicao = ''
                            if i < len(lines) and lines[i].strip() == 'Detalhes':
                                i += 1
                                if i < len(lines) and lines[i].strip().startswith('Fórmula:'):
                                    formula = lines[i].split(':',1)[1].strip(); i += 1
                                if i < len(lines) and lines[i].strip().startswith('Definição:'):
                                    definicao = lines[i].split(':',1)[1].strip(); i += 1
                            # Upsert
                            if not ticker or not nome: continue
                            ativo,_ = Ativo.objects.get_or_create(ticker=ticker)
                            Indicador.objects.update_or_create(
                                ativo=ativo, nome=nome,
                                defaults={
                                    'status': status or 'Moderado',
                                    'valor_texto': valor,
                                    'categoria': categoria,
                                    'fonte': fonte,
                                    'faixa': faixa,
                                    'analise': ' '.join(analise.split()),
                                    'formula': ' '.join(formula.split()),
                                    'definicao': ' '.join(definicao.split()),
                                }
                            )
                            total += 1
                        else:
                            i += 1
                continue

            # Try grid-like (EX2)
            headers = list(ativo_pat.finditer(html))
            for h in headers:
                ticker = h.group(1)
                sec = section_pat.search(html[h.end():])
                if not sec: continue
                ativo,_ = Ativo.objects.get_or_create(ticker=ticker)
                for cm in card_pat.finditer(sec.group(1)):
                    ch = cm.group(1)
                    status = rex(r'<span\s+class="chip[^>]*">\s*(.*?)\s*</span>', ch) or 'Moderado'
                    nome = rex(r'<h3\s+class="card__titulo">\s*(.*?)\s*</h3>', ch)
                    valor = rex(r'<p\s+class="card__valor">\s*(.*?)\s*</p>', ch)
                    nota = rex(r'<p\s+class="card__nota">\s*(.*?)\s*</p>', ch)
                    categoria, fonte = '', ''
                    if '•' in nota and 'Fonte' in nota:
                        parts = [p.strip() for p in nota.split('•')]
                        categoria = parts[0]
                        fonte_part = parts[1]
                        fonte = fonte_part.split(':',1)[1].strip() if ':' in fonte_part else fonte_part
                    else:
                        categoria = nota
                    faixa = rex(r'<p\s+class="card__faixa">\s*<strong>Faixa:</strong>\s*(.*?)\s*</p>', ch)
                    analise = rex(r'<p\s+class="card__desc">\s*(.*?)\s*</p>', ch)
                    formula = rex(r'<strong>Fórmula:</strong>\s*(.*?)\s*</p>', ch)
                    definicao = rex(r'<strong>Definição:</strong>\s*(.*?)\s*</p>', ch)
                    if not nome: continue
                    Indicador.objects.update_or_create(
                        ativo=ativo, nome=nome,
                        defaults={
                            'status': status,
                            'valor_texto': valor,
                            'categoria': categoria,
                            'fonte': fonte,
                            'faixa': faixa,
                            'analise': ' '.join(analise.split()),
                            'formula': ' '.join(formula.split()),
                            'definicao': ' '.join(definicao.split()),
                        }
                    )
                    total += 1

        self.stdout.write(self.style.SUCCESS(f'Importação concluída: {total} cards.'))
