
from django.urls import path
from . import views
app_name='indicadores'
urlpatterns=[
    path('', views.home, name='home'),
    path('ativo/<str:ticker>/', views.ativo_detail, name='ativo_detail'),
    path('horizontais/', views.horizontais, name='horizontais'),
    path('mosaico/', views.mosaico_status, name='mosaico'),
    path('lista/', views.lista_filtros, name='lista_filtros'),
]
