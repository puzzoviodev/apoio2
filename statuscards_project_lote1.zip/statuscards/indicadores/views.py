
from django.shortcuts import render, get_object_or_404
from .models import Ativo, Indicador
from django.db.models import Prefetch

# Home: lista ativos
def home(request):
    ativos = Ativo.objects.prefetch_related('indicadores').all()
    return render(request, 'indicadores/home.html', {'ativos': ativos})

# Detalhe padrão (grid)
def ativo_detail(request, ticker):
    ativo = get_object_or_404(Ativo, ticker=ticker)
    indicadores = ativo.indicadores.all().order_by('nome')
    return render(request, 'indicadores/ativo_detail.html', {'ativo': ativo,'indicadores': indicadores})

# Cards horizontais (agrupados por categoria/Agrupador)
def horizontais(request):
    qs = Indicador.objects.all().order_by('categoria','nome','ativo__ticker')
    grupos = {}
    for i in qs:
        grupos.setdefault(i.categoria or 'Sem categoria', []).append(i)
    return render(request, 'indicadores/cards_horizontais.html', {'grupos': grupos})

# Mosaico por classificação (status)
def mosaico_status(request):
    qs = Indicador.objects.all().order_by('status','ativo__ticker','nome')
    grupos = {}
    for i in qs:
        grupos.setdefault(i.status, []).append(i)
    ordem = ['Ótimo','Muito Bom','Bom','Moderado','Ruim','Crítico','Muito Crítico']
    grupos_ord = [(st, grupos.get(st, [])) for st in ordem]
    return render(request, 'indicadores/mosaico_classificacao.html', {'grupos': grupos_ord})

# Lista com filtros simples via querystring
def lista_filtros(request):
    qs = Indicador.objects.all()
    status = request.GET.get('status')
    cat = request.GET.get('categoria')
    ativo = request.GET.get('ativo')
    if status: qs = qs.filter(status=status)
    if cat: qs = qs.filter(categoria__icontains=cat)
    if ativo: qs = qs.filter(ativo__ticker__iexact=ativo)
    qs = qs.select_related('ativo').order_by('ativo__ticker','nome')
    # valores únicos para filtros
    statuses = Indicador.objects.values_list('status', flat=True).distinct().order_by('status')
    categorias = Indicador.objects.values_list('categoria', flat=True).distinct().order_by('categoria')
    ativos = Ativo.objects.values_list('ticker', flat=True).distinct().order_by('ticker')
    return render(request, 'indicadores/lista_filtros.html', {
        'indicadores': qs, 'statuses': statuses, 'categorias': categorias, 'ativos': ativos,
        'f_status': status or '', 'f_categoria': cat or '', 'f_ativo': ativo or ''
    })
