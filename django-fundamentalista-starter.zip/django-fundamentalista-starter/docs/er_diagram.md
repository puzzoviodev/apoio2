# Diagrama ER (Mermaid)

```mermaid
erDiagram
  Currency ||--o{ Company : moeda
  Exchange ||--o{ Company : lista
  Sector ||--o{ Industry : tem
  Industry ||--o{ Company : classifica
  Company ||--o{ Filing : entrega
  DataSource ||--o{ Filing : origina
  Filing ||--o{ FinancialStatement : compoe
  FinancialStatement ||--o{ Fact : contem
  Account ||--o{ Fact : referencia
  Company ||--o{ IndicatorValue : calcula
  IndicatorDefinition ||--o{ IndicatorValue : define
  Company ||--o{ Price : possui
  Company ||--o{ CorporateAction : evento
  Currency ||--o{ FXRate : base
  Currency ||--o{ FXRate : quote
  DataSource ||--o{ SourceMapping : mapeia

  Currency {
    char(3) code PK
    char symbol
  }
  Exchange {
    int id PK
    varchar name
    varchar country
  }
  Sector {
    int id PK
    varchar name
  }
  Industry {
    int id PK
    varchar name
    int sector_id FK
  }
  Company {
    int id PK
    varchar name
    varchar ticker
    varchar cnpj
    varchar lei
    int exchange_id FK
    int sector_id FK
    int industry_id FK
    int currency_id FK
  }
  DataSource {
    int id PK
    varchar name
    varchar url
    int reliability
  }
  Filing {
    int id PK
    int company_id FK
    int source_id FK
    date received_at
    date period_start
    date period_end
    bool is_annual
  }
  FinancialStatement {
    int id PK
    int company_id FK
    int filing_id FK
    char(2) type
  }
  Account {
    int id PK
    varchar code
    varchar name
    text description
  }
  Fact {
    int id PK
    int statement_id FK
    int account_id FK
    date period_end
    decimal value
    varchar unit
    int scale
  }
  IndicatorDefinition {
    int id PK
    varchar code
    varchar name
    text formula
    text description
  }
  IndicatorValue {
    int id PK
    int indicator_id FK
    int company_id FK
    date period_end
    decimal value
  }
  Price {
    int id PK
    int company_id FK
    date date
    decimal open
    decimal high
    decimal low
    decimal close
    bigint volume
  }
  CorporateAction {
    int id PK
    int company_id FK
    date date
    varchar type
    decimal value
    text notes
  }
  FXRate {
    int id PK
    int base_id FK
    int quote_id FK
    date date
    decimal rate
  }
  SourceMapping {
    int id PK
    int source_id FK
    varchar external_code
    int account_id FK
  }
```
