"""
Views do app 'core' demonstrando o uso das principais Class-Based Views do Django:
- ListView
- DetailView
- CreateView
- UpdateView
- DeleteView

Cada classe abaixo está exageradamente comentada para fins didáticos,
explicando o que cada atributo/método faz e porque foi usado.
"""
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Company
from .forms import CompanyForm

class CompanyListView(ListView):
    """Lista empresas com suporte a busca simples.

    Atributos principais utilizados:
    - model: informa qual tabela do ORM será listada.
    - template_name: caminho explícito do template a renderizar.
    - context_object_name: nome da variável no template.
    - paginate_by: paginação automática.

    Hooks sobrescritos:
    - get_queryset: permite filtrar/otimizar a consulta.
    - get_context_data: adicionar variáveis extras ao template.
    """
    model = Company
    template_name = 'core/company_list.html'
    context_object_name = 'companies'
    paginate_by = 10

    def get_queryset(self):
        # 1) Começamos do queryset padrão (SELECT * FROM company)
        qs = super().get_queryset().select_related('exchange', 'sector', 'industry', 'currency')
        # 2) Lemos um parâmetro de busca (?q=) para filtrar por nome/ticker
        q = self.request.GET.get('q')
        if q:
            qs = qs.filter(name__icontains=q) | qs.filter(ticker__icontains=q)
        # 3) Ordenamos alfabeticamente por nome
        return qs.order_by('name')

    def get_context_data(self, **kwargs):
        # Chamamos o contexto base (inclui 'companies' paginadas)
        ctx = super().get_context_data(**kwargs)
        # Passamos a query atual para manter o valor no input de busca
        ctx['q'] = self.request.GET.get('q', '')
        return ctx

class CompanyDetailView(DetailView):
    """Exibe detalhes de uma empresa específica (por pk na URL).

    - model: define a tabela alvo
    - template_name: arquivo HTML de detalhe
    - context_object_name: nome do objeto no template

    Hook útil:
    - get_context_data: agregamos informações relacionadas (fatos/indicadores).
    """
    model = Company
    template_name = 'core/company_detail.html'
    context_object_name = 'company'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        company = self.object  # o objeto resolvido pela pk/slug
        # Ex.: selecionar últimas 10 demonstrações/indicadores (se existirem)
        ctx['latest_facts'] = getattr(company, 'facts', None)
        ctx['indicator_values'] = getattr(company, 'indicator_values', None)
        return ctx

class CompanyCreateView(LoginRequiredMixin, CreateView):
    """Cria uma nova empresa.

    - LoginRequiredMixin: protege a view (apenas usuários autenticados)
    - model/form_class: qual modelo e formulário serão usados
    - success_url: para onde redirecionar após sucesso

    Hook:
    - form_valid: ponto para ajustar dados antes de salvar
    """
    model = Company
    form_class = CompanyForm
    template_name = 'core/company_form.html'
    success_url = reverse_lazy('core:company_list')

    def form_valid(self, form):
        # Ajuste de dados antes de chamar o fluxo padrão
        obj = form.save(commit=False)
        if obj.ticker:
            obj.ticker = obj.ticker.upper().strip()
        # Persistimos no banco
        obj.save()
        return super().form_valid(form)

class CompanyUpdateView(LoginRequiredMixin, UpdateView):
    """Edita uma empresa existente.

    - Busca a instância por pk na URL
    - Reutiliza o mesmo template e formulário de criação
    """
    model = Company
    form_class = CompanyForm
    template_name = 'core/company_form.html'
    success_url = reverse_lazy('core:company_list')

class CompanyDeleteView(LoginRequiredMixin, DeleteView):
    """Confirma e remove uma empresa.

    - template de confirmação explícito
    - após deletar, redireciona para a lista
    """
    model = Company
    template_name = 'core/company_confirm_delete.html'
    success_url = reverse_lazy('core:company_list')
