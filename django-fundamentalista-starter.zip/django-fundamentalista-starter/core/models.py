from django.db import models

class TimestampedModel(models.Model):
    """Mixin simples para carimbar criação/atualização."""
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

class Currency(TimestampedModel):
    """Moedas suportadas.
    - code: ISO 4217 (ex.: BRL, USD)
    - symbol: R$, US$, etc.
    """
    code = models.CharField(max_length=3, unique=True)
    symbol = models.CharField(max_length=5, blank=True)

    def __str__(self):
        return self.code

class Exchange(TimestampedModel):
    """Bolsa onde a empresa é listada (ex.: B3, NYSE)."""
    name = models.CharField(max_length=100, unique=True)
    country = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return self.name

class Sector(TimestampedModel):
    name = models.CharField(max_length=100, unique=True)
    def __str__(self):
        return self.name

class Industry(TimestampedModel):
    name = models.CharField(max_length=100, unique=True)
    sector = models.ForeignKey(Sector, on_delete=models.PROTECT, related_name='industries')
    def __str__(self):
        return self.name

class Company(TimestampedModel):
    """Empresa listada.
    - ticker: código na bolsa (ex.: PETR4)
    - cnpj/lei: identificadores legais
    - relações: exchange, setor e indústria
    - currency: moeda funcional para regras de conversão
    """
    name = models.CharField(max_length=200)
    ticker = models.CharField(max_length=20, unique=True)
    cnpj = models.CharField(max_length=18, blank=True)
    lei = models.CharField(max_length=20, blank=True)

    exchange = models.ForeignKey(Exchange, on_delete=models.PROTECT, related_name='companies')
    sector = models.ForeignKey(Sector, on_delete=models.PROTECT, related_name='companies')
    industry = models.ForeignKey(Industry, on_delete=models.PROTECT, related_name='companies')
    currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name='companies')

    def __str__(self):
        return f"{self.ticker} — {self.name}"

class DataSource(TimestampedModel):
    """Metadados de fontes (CVM, SEC, APIs...)."""
    name = models.CharField(max_length=100, unique=True)
    url = models.URLField(blank=True)
    reliability = models.PositiveSmallIntegerField(default=5, help_text='1–10 (quanto maior, mais confiável)')

    def __str__(self):
        return self.name

class Filing(TimestampedModel):
    """Pacote de demonstrações por data (ex.: DFP 2024)."""
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='filings')
    source = models.ForeignKey(DataSource, on_delete=models.PROTECT, related_name='filings')
    received_at = models.DateField()
    period_start = models.DateField()
    period_end = models.DateField()
    is_annual = models.BooleanField(default=True)

    class Meta:
        ordering = ['-period_end']

    def __str__(self):
        kind = 'Anual' if self.is_annual else 'Interim'
        return f"{self.company.ticker} {kind} até {self.period_end}"

class FinancialStatement(TimestampedModel):
    """Demonstração financeira vinculada a um Filing.
    - type: 'IS' (DRE), 'BS' (BP) ou 'CF' (DFC)
    """
    TYPE_CHOICES = [
        ('IS', 'Income Statement'),
        ('BS', 'Balance Sheet'),
        ('CF', 'Cash Flow'),
    ]
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='statements')
    filing = models.ForeignKey(Filing, on_delete=models.CASCADE, related_name='statements')
    type = models.CharField(max_length=2, choices=TYPE_CHOICES)

    def __str__(self):
        return f"{self.company.ticker} {self.get_type_display()} {self.filing.period_end}"

class Account(TimestampedModel):
    """Plano de contas normalizado (taxonomia própria)."""
    code = models.CharField(max_length=50, unique=True)  # ex.: REV_NET, EBITDA, CASH
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.code} — {self.name}"

class Fact(TimestampedModel):
    """Fato atômico: uma conta, um período, um valor.
    - statement: DRE/BP/DFC ao qual pertence
    - account: referência ao plano de contas
    - period_end: data fim (ex.: 31/12/2024)
    - value: valor numérico (em 'currency')
    - unit: unidade (ex.: 'BRL', 'shares')
    - scale: potência de 10 (ex.: 6 = milhões)
    """
    statement = models.ForeignKey(FinancialStatement, on_delete=models.CASCADE, related_name='facts')
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name='facts')
    period_end = models.DateField()
    value = models.DecimalField(max_digits=20, decimal_places=4)
    unit = models.CharField(max_length=20, default='BRL')
    scale = models.SmallIntegerField(default=0)

    class Meta:
        indexes = [
            models.Index(fields=['period_end']),
            models.Index(fields=['account']),
        ]

class IndicatorDefinition(TimestampedModel):
    """Fórmula declarativa de um indicador (ex.: ROE = NI / Equity)."""
    code = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=150)
    formula = models.TextField(help_text="Expressão em termos de 'Account.code' (ex.: NI / EQUITY)")
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.code} — {self.name}"

class IndicatorValue(TimestampedModel):
    """Valor calculado por empresa + período para um indicador."""
    indicator = models.ForeignKey(IndicatorDefinition, on_delete=models.CASCADE, related_name='values')
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='indicator_values')
    period_end = models.DateField()
    value = models.DecimalField(max_digits=20, decimal_places=6)

    class Meta:
        unique_together = ('indicator', 'company', 'period_end')
        indexes = [
            models.Index(fields=['period_end']),
            models.Index(fields=['indicator']),
        ]

class Price(TimestampedModel):
    """Série diária de preços (OHLCV)."""
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='prices')
    date = models.DateField()
    open = models.DecimalField(max_digits=12, decimal_places=4)
    high = models.DecimalField(max_digits=12, decimal_places=4)
    low = models.DecimalField(max_digits=12, decimal_places=4)
    close = models.DecimalField(max_digits=12, decimal_places=4)
    volume = models.BigIntegerField()

    class Meta:
        unique_together = ('company', 'date')
        ordering = ['-date']

class CorporateAction(TimestampedModel):
    """Eventos corporativos (dividendos, JCP, splits)."""
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='corporate_actions')
    date = models.DateField()
    type = models.CharField(max_length=20)
    value = models.DecimalField(max_digits=14, decimal_places=6)
    notes = models.TextField(blank=True)

class FXRate(TimestampedModel):
    """Taxa de câmbio por data (de->para)."""
    base = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name='fx_base')
    quote = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name='fx_quote')
    date = models.DateField()
    rate = models.DecimalField(max_digits=18, decimal_places=8)

    class Meta:
        unique_together = ('base', 'quote', 'date')

class SourceMapping(TimestampedModel):
    """Mapeia códigos da fonte externa para 'Account'."""
    source = models.ForeignKey(DataSource, on_delete=models.CASCADE, related_name='mappings')
    external_code = models.CharField(max_length=100)
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name='mappings')

    class Meta:
        unique_together = ('source', 'external_code')

class ImportJob(TimestampedModel):
    """Audita importações (quando, de onde, status)."""
    source = models.ForeignKey(DataSource, on_delete=models.PROTECT, related_name='import_jobs')
    started_at = models.DateTimeField()
    finished_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, default='RUNNING')
    message = models.TextField(blank=True)
