from django.contrib import admin
from .models import (
    Currency, Exchange, Sector, Industry, Company,
    DataSource, Filing, FinancialStatement, Account, Fact,
    IndicatorDefinition, IndicatorValue, Price, CorporateAction,
    FXRate, SourceMapping, ImportJob
)

for m in [Currency, Exchange, Sector, Industry, Company,
          DataSource, Filing, FinancialStatement, Account, Fact,
          IndicatorDefinition, IndicatorValue, Price, CorporateAction,
          FXRate, SourceMapping, ImportJob]:
    try:
        admin.site.register(m)
    except admin.sites.AlreadyRegistered:
        pass
