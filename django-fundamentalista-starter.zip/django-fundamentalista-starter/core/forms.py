from django import forms
from .models import Company

class CompanyForm(forms.ModelForm):
    class Meta:
        model = Company
        fields = ['name', 'ticker', 'cnpj', 'lei', 'exchange', 'sector', 'industry', 'currency']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'ticker': forms.TextInput(attrs={'class': 'form-control', 'style': 'text-transform:uppercase;'}),
        }
