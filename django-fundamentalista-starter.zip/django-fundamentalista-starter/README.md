# Projeto Django — Análise Fundamentalista (Starter)

Este pacote foi criado para você rodar **imediatamente** no seu PC (Windows/macOS/Linux),
com **exemplos hiper-comentados** de *Class-Based Views* (CBVs): `ListView`, `DetailView`,
`CreateView`, `UpdateView` e `DeleteView`. Também inclui um **modelo de dados** inicial
para empresas, demonstrações financeiras, indicadores e fontes de dados, além de um diagrama ER.

> Autor: gerado para **Silvio Luiz Puzzovio** (Coord. Sistemas)

---

## 1) Como rodar no seu PC (Windows/macOS/Linux)

### 1.1 Pré-requisitos
- Python 3.10+ instalado (`python --version`).
- Pip atualizado: `python -m pip install --upgrade pip`.

### 1.2 Passo a passo

> **Windows (PowerShell)**
```powershell
cd .\django-fundamentalista-starter
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser  # siga o prompt
python manage.py runserver
```

> **macOS / Linux (bash/zsh)**
```bash
cd django-fundamentalista-starter
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser  # siga o prompt
python manage.py runserver
```

Abra: http://127.0.0.1:8000/

### 1.3 Estrutura do projeto
```
django-fundamentalista-starter/
├─ manage.py
├─ requirements.txt
├─ fundamentus/          # Projeto Django (settings/urls)
│  ├─ settings.py
│  ├─ urls.py
│  ├─ asgi.py
│  └─ wsgi.py
├─ core/                 # App principal (modelos, views, urls)
│  ├─ models.py
│  ├─ views.py
│  ├─ urls.py
│  ├─ forms.py
│  ├─ admin.py
│  └─ migrations/
├─ templates/
│  ├─ base.html
│  └─ core/
│     ├─ company_list.html
│     ├─ company_detail.html
│     ├─ company_form.html
│     └─ company_confirm_delete.html
└─ docs/
   └─ er_diagram.md
```

---

## 2) CBVs explicadas — com exemplos hiper-comentados

Abaixo um panorama prático. O **código completo** e comentado está em `core/views.py`
e nos templates correspondentes.

### 2.1 `ListView` — listar registros
Use quando você precisa exibir uma lista paginada/filtrável.

**URL:** `/companies/`

```python
# core/views.py (trecho)
from django.views.generic import ListView
from .models import Company

class CompanyListView(ListView):
    model = Company                      # Modelo base para a lista
    template_name = 'core/company_list.html'  # Template explícito
    context_object_name = 'companies'    # Nome do contexto no template
    paginate_by = 10                     # Paginação (10 por página)

    def get_queryset(self):
        # Filtro opcional por querystring ?q= (nome ou ticker)
        qs = super().get_queryset().select_related('exchange', 'sector', 'industry')
        q = self.request.GET.get('q')
        if q:
            qs = qs.filter(name__icontains=q) | qs.filter(ticker__icontains=q)
        return qs.order_by('name')
```

### 2.2 `DetailView` — detalhes de um registro
Exibe campos e relações de um registro específico.

**URL:** `/companies/<pk>/`

```python
from django.views.generic import DetailView

class CompanyDetailView(DetailView):
    model = Company
    template_name = 'core/company_detail.html'
    context_object_name = 'company'

    def get_context_data(self, **kwargs):
        # Acrescenta indicadores e últimas demonstrações ao contexto
        ctx = super().get_context_data(**kwargs)
        company = self.object
        ctx['latest_facts'] = company.facts.select_related('statement', 'account').order_by('-period_end')[:25]
        ctx['indicators'] = company.indicator_values.select_related('indicator').order_by('-period_end')[:25]
        return ctx
```

### 2.3 `CreateView` — criar novo registro
Inclui validação com `ModelForm` e redireciona ao sucesso.

**URL:** `/companies/new/`

```python
from django.views.generic import CreateView
from django.urls import reverse_lazy
from .forms import CompanyForm

class CompanyCreateView(CreateView):
    model = Company
    form_class = CompanyForm
    template_name = 'core/company_form.html'
    success_url = reverse_lazy('core:company_list')

    def form_valid(self, form):
        # Exemplo: normaliza ticker para maiúsculas antes de salvar
        obj = form.save(commit=False)
        if obj.ticker:
            obj.ticker = obj.ticker.upper()
        obj.save()
        return super().form_valid(form)
```

### 2.4 `UpdateView` — atualizar registro existente

**URL:** `/companies/<pk>/edit/`

```python
from django.views.generic import UpdateView

class CompanyUpdateView(UpdateView):
    model = Company
    form_class = CompanyForm
    template_name = 'core/company_form.html'
    success_url = reverse_lazy('core:company_list')
```

### 2.5 `DeleteView` — excluir registro

**URL:** `/companies/<pk>/delete/`

```python
from django.views.generic import DeleteView

class CompanyDeleteView(DeleteView):
    model = Company
    template_name = 'core/company_confirm_delete.html'
    success_url = reverse_lazy('core:company_list')
```

> **Dica:** Todos os templates possuem comentários explicando cada bloco.

---

## 3) Modelo de dados (MVP robusto)

### Entidades principais
- **Currency**: moedas e símbolo (ex.: BRL, USD).
- **Exchange**: bolsa (ex.: B3) e país.
- **Sector / Industry**: taxonomia setorial.
- **Company**: empresa listada, com `ticker`, CNPJ/LEI, `exchange`, `currency` etc.
- **DataSource**: metadados sobre fonte (ex.: CVM, SEC, API de cotações) e confiabilidade.
- **Filing**: pacote de demonstrações entregue em uma data (DFP/ITR/10-K/10-Q).
- **FinancialStatement**: tipo (`IS`, `BS`, `CF`) vinculado ao `Filing` e à `Company`.
- **Account**: plano de contas normalizado (ex.: Receita Líquida, EBITDA, Caixa).
- **Fact**: valor atômico (conta X período), com granularidade, moeda e precisão.
- **IndicatorDefinition**: fórmula declarativa (ex.: ROE = Lucro Líquido / Patrimônio Líquido).
- **IndicatorValue**: valor calculado por empresa/período a partir de `Fact`s.
- **Price**: série histórica diária (OHLCV) por empresa.
- **CorporateAction**: eventos (dividendos, JCP, splits) que afetam `Price` e indicadores.
- **FXRate**: câmbio por data, para conversão entre moedas.
- **SourceMapping**: mapeia códigos da fonte externa → `Account` normalizada.
- **ImportJob**: auditoria/trace de importações e qualidade dos dados.

O **ERD** em Mermaid está em `docs/er_diagram.md`.

---

## 4) Próximos passos sugeridos
- Implementar comandos `manage.py` para importar DFP/ITR (CVM) e cotações.
- Cachear `IndicatorValue` via *signals* pós-importação.
- Adicionar *permissions* e *login required* para `Create/Update/Delete`.
- Testes unitários para fórmulas de indicadores.

---

## 5) Notas
- Banco padrão: **SQLite** (dev). Para produção, use Postgres.
- Locale: `pt-br`, timezone `America/Sao_Paulo`.

Bom estudo e bons investimentos! 🚀
