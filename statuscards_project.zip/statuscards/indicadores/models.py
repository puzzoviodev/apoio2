
from django.db import models

# --- Choices de status com cores predefinidas para estilização ---
STATUS_CHOICES = [
    ('Muito Crítico', 'Muito Crítico'),
    ('Crítico', 'Crítico'),
    ('Ruim', 'Ruim'),
    ('Moderado', 'Moderado'),
    ('Bom', 'Bom'),
    ('Muito Bom', 'Muito Bom'),
    ('Ótimo', 'Ótimo'),
]

class Ativo(models.Model):
    """Representa um ticker (ex.: ABEV3)."""
    ticker = models.CharField(max_length=12, unique=True)

    class Meta:
        ordering = ['ticker']

    def __str__(self):  # pragma: no cover
        return self.ticker

class Indicador(models.Model):
    """Um card com indicador, sua avaliação e textos explicativos."""

    ativo = models.ForeignKey(Ativo, on_delete=models.CASCADE, related_name='indicadores')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    nome = models.CharField(max_length=120)

    # Guardamos o valor como texto para preservar a formatação original
    valor_texto = models.CharField(max_length=50, blank=True)

    categoria = models.CharField(max_length=80, blank=True)
    fonte = models.CharField(max_length=120, blank=True)
    faixa = models.CharField(max_length=200, blank=True)

    analise = models.TextField(blank=True)
    formula = models.TextField(blank=True)
    definicao = models.TextField(blank=True)

    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['ativo__ticker', 'nome']
        indexes = [
            models.Index(fields=['ativo', 'status']),
        ]

    def __str__(self):  # pragma: no cover
        return f"{self.ativo} · {self.nome}"
