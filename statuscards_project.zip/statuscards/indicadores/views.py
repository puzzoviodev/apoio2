
from django.shortcuts import render, get_object_or_404
from .models import Ativo

# Página inicial: lista de ativos
# Comentários detalhados explicando cada etapa para facilitar o estudo.
def home(request):
    # Consulta todos os ativos já com prefetch dos indicadores para evitar N+1
    ativos = Ativo.objects.prefetch_related('indicadores').all()
    # Renderiza o template passando o queryset no contexto
    return render(request, 'indicadores/home.html', {'ativos': ativos})

# Página de detalhes do ativo: mostra o grid de cards

def ativo_detail(request, ticker):
    ativo = get_object_or_404(Ativo, ticker=ticker)
    # Ordena os indicadores por nome; você pode mudar para status
    indicadores = ativo.indicadores.all().order_by('nome')
    return render(request, 'indicadores/ativo_detail.html', {
        'ativo': ativo,
        'indicadores': indicadores,
    })
