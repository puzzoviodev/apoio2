
# Status Cards (Django)

Projeto Django gerado automaticamente a partir de um HTML/Markdown com cartões de indicadores.

## Como rodar

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata indicadores/fixtures/indicadores.json
python manage.py runserver
```

Abra http://127.0.0.1:8000

## Estrutura
- `indicadores/models.py`: modelos `Ativo` e `Indicador`.
- `indicadores/views.py`: views para home e detalhe do ativo.
- `indicadores/templates/indicadores/`: templates HTML (base, home, ativo_detail).
- `indicadores/static/indicadores/css/style.css`: CSS para grid.
- `indicadores/fixtures/indicadores.json`: dados extraídos do HTML.

## Observações
- O valor é mantido como texto (`valor_texto`) para preservar formatação.
- Status viram classes CSS (`status-<slug>`) para colorir o selo.
