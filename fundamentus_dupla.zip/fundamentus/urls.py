from django.urls import path
from . import views

app_name = "fundamentus"

urlpatterns = [
    path("table/", views.detailed_table, name="detailed_table"),
    path("heatmap/status/", views.status_heatmap, name="status_heatmap"),
]
