from collections import defaultdict
from django.db.models import Count
from django.db import models
from django.shortcuts import render
from django.http import HttpRequest, HttpResponse
from .models import Company, IndicatorValue, Classification


def detailed_table(request: HttpRequest) -> HttpResponse:
    """Tabela detalhada por ticker, com colunas:
    Indicador | Valor | Status | Categoria | Faixa | Resumo.
    Query param: ?tickers=ABEV3,AERI3
    """
    raw = (request.GET.get("tickers") or "").strip()
    if raw:
        tickers = [t.strip().upper() for t in raw.split(',') if t.strip()]
    else:
        tickers = list(Company.objects.order_by('ticker').values_list('ticker', flat=True)[:2]) or ["ABEV3", "AERI3"]

    qs = (
        IndicatorValue.objects.select_related("indicator", "company")
        .filter(company__ticker__in=tickers)
        .order_by("company__ticker", "indicator__group", "indicator__label")
    )

    values_by_ticker = defaultdict(list)
    for iv in qs:
        values_by_ticker[iv.company.ticker].append(iv)

    total_cards = qs.count()

    return render(
        request,
        "fundamentus/v1_tabela.html",
        {
            "tickers": tickers,
            "values_by_ticker": values_by_ticker,
            "total_cards": total_cards,
        },
    )


def status_heatmap(request: HttpRequest) -> HttpResponse:
    """Heatmap de status (cor por classificação) agrupado por Categoria (group) por ticker.
    Query param: ?tickers=ABEV3,AERI3
    """
    raw = (request.GET.get("tickers") or "").strip()
    if raw:
        tickers = [t.strip().upper() for t in raw.split(',') if t.strip()]
    else:
        tickers = list(Company.objects.order_by('ticker').values_list('ticker', flat=True)[:2]) or ["ABEV3", "AERI3"]

    qs = (
        IndicatorValue.objects.select_related("indicator", "company")
        .filter(company__ticker__in=tickers)
        .order_by("company__ticker", "indicator__group", "indicator__label")
    )

    # Estrutura: heatmap[ticker][group] = list of iv
    heatmap = defaultdict(lambda: defaultdict(list))
    for iv in qs:
        heatmap[iv.company.ticker][iv.indicator.group].append(iv)

    return render(
        request,
        "fundamentus/v2_heatmap.html",
        {
            "tickers": tickers,
            "heatmap": heatmap,
        },
    )
