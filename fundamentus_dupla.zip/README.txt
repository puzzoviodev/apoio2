Dupla: Tabela detalhada + Heatmap de status
===============================================
Rotas adicionadas:
  - /fundamentus/table/?tickers=ABEV3,AERI3
  - /fundamentus/heatmap/status/?tickers=ABEV3,AERI3

Como usar:
  1) Adicione 'fundamentus' ao INSTALLED_APPS e inclua as URLs:
       path('fundamentus/', include('fundamentus.urls'))
  2) Gere/migre e carregue seus indicadores (use seus seeds anteriores).
  3) Acesse as rotas acima. Os componentes seguem o mesmo layout base.
