from django.contrib import admin
from .models import Company, IndicatorDefinition, IndicatorValue

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    search_fields = ["ticker", "name"]
    list_display = ["ticker", "name"]

@admin.register(IndicatorDefinition)
class IndicatorDefinitionAdmin(admin.ModelAdmin):
    search_fields = ["code", "label"]
    list_display = ["code", "label", "group"]

@admin.register(IndicatorValue)
class IndicatorValueAdmin(admin.ModelAdmin):
    search_fields = ["company__ticker", "indicator__label", "indicator__code"]
    list_display = ["company", "indicator", "value_display", "classification", "updated_at"]
    list_filter = ["classification", "indicator__group", "source"]
