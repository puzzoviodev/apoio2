from django.urls import path
from . import views

app_name = 'fundamentus'

urlpatterns = [
    path('', views.home_ajax, name='home'),
    path('overview/<str:ticker>/', views.overview, name='overview'),
    path('table/', views.detailed_table, name='detailed_table'),
    path('heatmap/status/', views.status_heatmap, name='status_heatmap'),
    path('xhr/table-fragment/', views.detailed_table_fragment, name='table_fragment'),
    path('xhr/heatmap-status-fragment/', views.status_heatmap_fragment, name='status_heatmap_fragment'),
    path('xhr/run-xyz/', views.RunXYZAjaxView.as_view(), name='run_xyz_ajax'),
]
