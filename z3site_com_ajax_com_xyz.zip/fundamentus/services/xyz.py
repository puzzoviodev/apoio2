from decimal import Decimal
from .models import Company, IndicatorDefinition, IndicatorValue, IndicatorGroup, Classification

class XYZService:
    """Serviço responsável por popular/atualizar as tabelas a partir de uma fonte externa.
    Aqui está um mock simples para demonstrar a integração. Substitua pelo seu pipeline real.
    """
    def run(self) -> dict:
        # garante empresas
        abev3, _ = Company.objects.get_or_create(ticker='ABEV3', defaults={'name': 'Ambev S.A.'})
        aeri3, _ = Company.objects.get_or_create(ticker='AERI3', defaults={'name': 'Aeris Energy'})
        # garante indicadores essenciais
        defs = [
            dict(code='dy', label='D.Y', group=IndicatorGroup.RENTABILIDADE, formula='DY', definition='Dividend Yield', band='DY > 6%'),
            dict(code='ev_ebitda', label='EV/EBITDA', group=IndicatorGroup.VALUATION, formula='EV/EBITDA', definition='Valuation vs EBITDA', band='4 < x <= 8'),
        ]
        created_defs = 0
        for d in defs:
            obj, created = IndicatorDefinition.objects.get_or_create(code=d['code'], defaults=d)
            if not created:
                for f in ['label','group','formula','definition','band']:
                    setattr(obj, f, d[f])
                obj.save()
            else:
                created_defs += 1
        # popula valores
        data = [
            (abev3, 'dy', Decimal('8.48'), '8,48%', Classification.OTIMO, 'XYZ: DY robusto'),
            (abev3, 'ev_ebitda', Decimal('5.45'), '5,45', Classification.BOM, 'XYZ: EV/EBITDA equilibrado'),
            (aeri3, 'dy', Decimal('0'), '0,0%', Classification.CRITICO, 'XYZ: sem dividendos'),
            (aeri3, 'ev_ebitda', Decimal('-2.35'), '-2,35', Classification.MUITO_CRITICO, 'XYZ: EBITDA negativo'),
        ]
        created_vals = 0
        updated_vals = 0
        for comp, code, raw, disp, klass, desc in data:
            ind = IndicatorDefinition.objects.get(code=code)
            obj, created = IndicatorValue.objects.update_or_create(
                company=comp, indicator=ind,
                defaults=dict(value_raw=raw, value_display=disp, classification=klass, description=desc, source='XYZ')
            )
            if created:
                created_vals += 1
            else:
                updated_vals += 1
        return {
            'created_definitions': created_defs,
            'created_values': created_vals,
            'updated_values': updated_vals,
        }
