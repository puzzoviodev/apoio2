from collections import defaultdict
from django.db import models
from django.db.models import Count
from django.shortcuts import render, get_object_or_404
from django.http import HttpRequest, HttpResponse, HttpResponseBadRequest, JsonResponse
from django.views import View
from .models import Company, IndicatorValue
from .services.xyz import XYZService

# Home AJAX

def home_ajax(request: HttpRequest) -> HttpResponse:
    suggested = list(Company.objects.values_list('ticker', flat=True).order_by('ticker')[:10])
    return render(request, 'fundamentus/home_ajax.html', { 'suggested': suggested })

# Overview (mantida)

def overview(request: HttpRequest, ticker: str) -> HttpResponse:
    t = ticker.strip().upper()
    company = get_object_or_404(Company, ticker__iexact=t)
    base_qs = IndicatorValue.objects.filter(company=company)
    by_class = base_qs.values('classification').annotate(total=Count('id')).order_by('classification')
    links = [
        { 'name': 'Tabela (página inteira)', 'url': f"/fundamentus/table/?tickers={t}" },
        { 'name': 'Heatmap status (página inteira)', 'url': f"/fundamentus/heatmap/status/?tickers={t}" },
    ]
    return render(request, 'fundamentus/overview.html', {
        'company': company, 'ticker': t, 'by_class': by_class, 'links': links
    })

# Páginas completas

def detailed_table(request: HttpRequest) -> HttpResponse:
    raw = (request.GET.get('tickers') or '').strip()
    tickers = [t.strip().upper() for t in raw.split(',') if t.strip()] if raw else list(Company.objects.order_by('ticker').values_list('ticker', flat=True)[:2])
    qs = (
        IndicatorValue.objects.select_related('indicator','company')
        .filter(company__ticker__in=tickers)
        .order_by('company__ticker','indicator__group','indicator__label')
    )
    values_by_ticker = defaultdict(list)
    for iv in qs:
        values_by_ticker[iv.company.ticker].append(iv)
    total_cards = qs.count()
    return render(request, 'fundamentus/v1_tabela.html', { 'tickers': tickers, 'values_by_ticker': values_by_ticker, 'total_cards': total_cards })


def status_heatmap(request: HttpRequest) -> HttpResponse:
    raw = (request.GET.get('tickers') or '').strip()
    tickers = [t.strip().upper() for t in raw.split(',') if t.strip()] if raw else list(Company.objects.order_by('ticker').values_list('ticker', flat=True)[:2])
    qs = (
        IndicatorValue.objects.select_related('indicator','company')
        .filter(company__ticker__in=tickers)
        .order_by('company__ticker','indicator__group','indicator__label')
    )
    heatmap = defaultdict(lambda: defaultdict(list))
    for iv in qs:
        heatmap[iv.company.ticker][iv.indicator.group].append(iv)
    return render(request, 'fundamentus/v2_heatmap.html', { 'tickers': tickers, 'heatmap': heatmap })

# Fragmentos AJAX

def detailed_table_fragment(request: HttpRequest) -> HttpResponse:
    raw = (request.GET.get('tickers') or '').strip()
    if not raw:
        return HttpResponseBadRequest('Parametro tickers é obrigatório')
    tickers = [t.strip().upper() for t in raw.split(',') if t.strip()]
    qs = (
        IndicatorValue.objects.select_related('indicator','company')
        .filter(company__ticker__in=tickers)
        .order_by('company__ticker','indicator__group','indicator__label')
    )
    values_by_ticker = defaultdict(list)
    for iv in qs:
        values_by_ticker[iv.company.ticker].append(iv)
    total_cards = qs.count()
    return render(request, 'fundamentus/partials/table_fragment.html', { 'tickers': tickers, 'values_by_ticker': values_by_ticker, 'total_cards': total_cards })


def status_heatmap_fragment(request: HttpRequest) -> HttpResponse:
    raw = (request.GET.get('tickers') or '').strip()
    if not raw:
        return HttpResponseBadRequest('Parametro tickers é obrigatório')
    tickers = [t.strip().upper() for t in raw.split(',') if t.strip()]
    qs = (
        IndicatorValue.objects.select_related('indicator','company')
        .filter(company__ticker__in=tickers)
        .order_by('company__ticker','indicator__group','indicator__label')
    )
    heatmap = defaultdict(lambda: defaultdict(list))
    for iv in qs:
        heatmap[iv.company.ticker][iv.indicator.group].append(iv)
    return render(request, 'fundamentus/partials/heatmap_fragment.html', { 'tickers': tickers, 'heatmap': heatmap })

# Botão XYZ (AJAX) — POST → JSON
class RunXYZAjaxView(View):
    def post(self, request: HttpRequest) -> JsonResponse:
        svc = XYZService()
        summary = svc.run()
        return JsonResponse({ 'ok': True, 'summary': summary })
