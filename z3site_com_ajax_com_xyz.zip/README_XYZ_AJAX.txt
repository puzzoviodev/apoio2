COM AJAX + Botão XYZ
======================

- Home AJAX: ticker + botões "Ver Tabela", "Ver Heatmap" e **"Popular base (XYZ)"** (POST via fetch, JSON).
- Endpoint: /fundamentus/xhr/run-xyz/ → chama `XYZService().run()` e retorna resumo em JSON.
- Páginas completas continuam disponíveis.

Como rodar
---------
1) pip install django
2) python manage.py makemigrations && python manage.py migrate
3) (opcional) python manage.py load_sample_min
4) python manage.py runserver
5) http://localhost:8000/fundamentus/
