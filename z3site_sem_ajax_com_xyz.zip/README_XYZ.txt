Sem AJAX + Botão XYZ
======================

- Home: campo Ticker + botão "Popular base (XYZ)".
- Ao clicar em XYZ, a classe `XYZService` (fundamentus/services/xyz.py) popula/atualiza as tabelas.
- O restante do código permanece igual (Overview, Tabela, Heatmap).

Como rodar
---------
1) pip install django
2) python manage.py makemigrations && python manage.py migrate
3) (opcional) python manage.py load_sample_min
4) python manage.py runserver
5) http://localhost:8000/fundamentus/
