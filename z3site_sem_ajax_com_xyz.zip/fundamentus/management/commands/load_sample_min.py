from decimal import Decimal
from django.core.management.base import BaseCommand
from fundamentus.models import Company, IndicatorDefinition, IndicatorValue, IndicatorGroup, Classification

class Command(BaseCommand):
    help = 'Carrega amostras mínimas (pode usar XYZ depois).'

    def handle(self, *args, **options):
        Company.objects.get_or_create(ticker='ABEV3', defaults={'name': 'Ambev S.A.'})
        Company.objects.get_or_create(ticker='AERI3', defaults={'name': 'Aeris Energy'})
        self.stdout.write(self.style.SUCCESS('Empresas criadas. Use o botão XYZ para popular indicadores.'))
