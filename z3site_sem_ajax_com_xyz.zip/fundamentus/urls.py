from django.urls import path
from . import views

app_name = 'fundamentus'

urlpatterns = [
    path('', views.home, name='home'),
    path('overview/<str:ticker>/', views.overview, name='overview'),
    path('table/', views.detailed_table, name='detailed_table'),
    path('heatmap/status/', views.status_heatmap, name='status_heatmap'),
    path('run-xyz/', views.RunXYZView.as_view(), name='run_xyz'),
]
