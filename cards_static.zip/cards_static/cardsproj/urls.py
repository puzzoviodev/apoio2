from django.contrib import admin
from django.urls import path
from cards.views import StaticCardsView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', StaticCardsView.as_view(), name='home'),
]
