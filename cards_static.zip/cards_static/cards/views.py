from django.views.generic import TemplateView

class StaticCardsView(TemplateView):
    template_name = 'cards/static_page.html'
