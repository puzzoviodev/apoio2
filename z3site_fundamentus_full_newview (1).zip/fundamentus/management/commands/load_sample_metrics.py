from decimal import Decimal
from django.core.management.base import BaseCommand
from fundamentus.models import Company, IndicatorDefinition, IndicatorValue, IndicatorGroup, Classification

class Command(BaseCommand):
    help = 'Carrega amostras mínimas para ABEV3 e AERI3.'

    def handle(self, *args, **options):
        abev3, _ = Company.objects.get_or_create(ticker='ABEV3', defaults={'name': 'Ambev S.A.'})
        aeri3, _ = Company.objects.get_or_create(ticker='AERI3', defaults={'name': 'Aeris Energy'})
        defs = [
            dict(code='dy', label='D.Y', group=IndicatorGroup.RENTABILIDADE, formula='DY = (Div/Ação / Preço) * 100', definition='Dividend Yield.', band='DY > 6%', reference=''),
            dict(code='pl', label='P/L', group=IndicatorGroup.SAUDE, formula='P/L = Preço / LPA', definition='Preço/Lucro.', band='—', reference=''),
            dict(code='ev_ebitda', label='EV/EBITDA', group=IndicatorGroup.VALUATION, formula='EV/EBITDA = EV / EBITDA', definition='Valuation vs EBITDA.', band='4 < x <= 8', reference=''),
            dict(code='p_ebitda', label='P/EBITDA', group=IndicatorGroup.VALUATION, formula='P/EBITDA = VM / EBITDA', definition='Preço/EBITDA.', band='0 <= x <= 6', reference=''),
            dict(code='tag_along', label='TAG ALONG', group=IndicatorGroup.GOVERNANCA, formula='Tag Along (%)', definition='Proteção aos minoritários.', band='80%–100%', reference=''),
        ]
        defs_map = {}
        for d in defs:
            obj, _ = IndicatorDefinition.objects.get_or_create(code=d['code'], defaults=d)
            for f in ['label','group','formula','definition','band','reference']:
                setattr(obj, f, d[f])
            obj.save()
            defs_map[d['code']] = obj
        samples = [
            dict(ticker='ABEV3', code='dy', value_display='8,48%', value_raw=Decimal('8.48'), classification=Classification.OTIMO, description='Dividendos robustos.', source='StausInvest'),
            dict(ticker='ABEV3', code='pl', value_display='13,25', value_raw=Decimal('13.25'), classification=Classification.OTIMO, description='P/L confortável.', source='StausInvest'),
            dict(ticker='ABEV3', code='ev_ebitda', value_display='5,45', value_raw=Decimal('5.45'), classification=Classification.BOM, description='Valuation equilibrado.', source='StausInvest'),
            dict(ticker='ABEV3', code='p_ebitda', value_display='5,88', value_raw=Decimal('5.88'), classification=Classification.OTIMO, description='Faixa barata.', source='StausInvest'),
            dict(ticker='ABEV3', code='tag_along', value_display='80%', value_raw=Decimal('80'), classification=Classification.MODERADO, description='Proteção padrão.', source='StausInvest'),
            dict(ticker='AERI3', code='dy', value_display='0,0%', value_raw=Decimal('0'), classification=Classification.CRITICO, description='Sem dividendos.', source='StausInvest'),
            dict(ticker='AERI3', code='pl', value_display='-0,22', value_raw=Decimal('-0.22'), classification=Classification.CRITICO, description='PL negativo.', source='StausInvest'),
            dict(ticker='AERI3', code='ev_ebitda', value_display='-2,35', value_raw=Decimal('-2.35'), classification=Classification.MUITO_CRITICO, description='EBITDA negativo.', source='StausInvest'),
            dict(ticker='AERI3', code='p_ebitda', value_display='-0,32', value_raw=Decimal('-0.32'), classification=Classification.MUITO_CRITICO, description='P/EBITDA negativo.', source='StausInvest'),
            dict(ticker='AERI3', code='tag_along', value_display='100%', value_raw=Decimal('100'), classification=Classification.OTIMO, description='Proteção total.', source='StausInvest'),
        ]
        for s in samples:
            comp = Company.objects.get(ticker=s['ticker'])
            ind = defs_map[s['code']]
            IndicatorValue.objects.update_or_create(
                company=comp, indicator=ind,
                defaults=dict(value_raw=s['value_raw'], value_display=s['value_display'], classification=s['classification'], description=s['description'], source=s['source'])
            )
        self.stdout.write(self.style.SUCCESS('Amostras mínimas carregadas.'))
