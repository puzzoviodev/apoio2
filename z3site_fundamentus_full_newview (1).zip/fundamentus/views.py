from collections import defaultdict
from django.db.models import Count
from django.db import models
from django.shortcuts import get_object_or_404, render, redirect
from django.http import HttpRequest, HttpResponse
from .models import Company, IndicatorValue, Classification
from .registry import ENTRIES

# --- Home & Overview ---

def home(request: HttpRequest) -> HttpResponse:
    if request.method == 'POST':
        ticker = (request.POST.get('ticker') or '').strip().upper()
        if ticker:
            return redirect('fundamentus:overview', ticker=ticker)
    tickers = list(Company.objects.values_list('ticker', flat=True).order_by('ticker')[:10])
    return render(request, 'fundamentus/home.html', { 'suggested': tickers })


def overview(request: HttpRequest, ticker: str) -> HttpResponse:
    t = ticker.strip().upper()
    company = get_object_or_404(Company, ticker__iexact=t)
    base_qs = IndicatorValue.objects.filter(company=company)
    by_class = base_qs.values('classification').annotate(total=Count('id')).order_by('classification')
    others = list(Company.objects.exclude(ticker__iexact=t).values_list('ticker', flat=True).order_by('ticker')[:20])
    other = (request.GET.get('b') or (others[0] if others else '')).upper() if others else ''
    links = []
    for entry in ENTRIES:
        try:
            url = entry.build_url(t, other)
        except Exception:
            url = '#'
        links.append({ 'key': entry.key, 'name': entry.name, 'desc': entry.desc, 'url': url })
    return render(request, 'fundamentus/overview.html', {
        'company': company,
        'ticker': t,
        'other': other,
        'others': others,
        'by_class': by_class,
        'links': links,
    })

# --- Telas ---

def flip_cards_3d(request: HttpRequest, ticker: str) -> HttpResponse:
    company = get_object_or_404(Company, ticker__iexact=ticker)
    values = (IndicatorValue.objects.select_related('indicator','company').filter(company=company)
              .order_by('indicator__group','indicator__label'))
    return render(request, 'fundamentus/flip_cards_3d.html', {'company': company, 'values': values})


def filter_togglecard(request: HttpRequest) -> HttpResponse:
    q = (request.GET.get('q') or '').strip()
    klass = (request.GET.get('class') or '').strip()
    queryset = IndicatorValue.objects.select_related('indicator','company')
    if q:
        queryset = queryset.filter(
            models.Q(company__ticker__icontains=q) |
            models.Q(indicator__label__icontains=q) |
            models.Q(indicator__code__icontains=q)
        )
    if klass in dict(Classification.choices):
        queryset = queryset.filter(classification=klass)
    queryset = queryset.order_by('company__ticker','indicator__group','indicator__label')
    classes = [c[0] for c in Classification.choices]
    return render(request, 'fundamentus/filter_togglecard.html', {
        'values': queryset, 'q': q, 'klass': klass, 'classes': classes
    })


def quickstats(request: HttpRequest) -> HttpResponse:
    ticker = (request.GET.get('ticker') or '').strip()
    base_qs = IndicatorValue.objects.select_related('company')
    if ticker:
        base_qs = base_qs.filter(company__ticker__iexact=ticker)
    by_class = base_qs.values('classification').annotate(total=Count('id')).order_by('classification')
    by_company = base_qs.values('company__ticker').annotate(total=Count('id')).order_by('company__ticker')
    return render(request, 'fundamentus/quickstats.html', {
        'ticker': ticker, 'by_class': by_class, 'by_company': by_company,
        'all_classes': [c[0] for c in Classification.choices]
    })


def modal_compare(request: HttpRequest) -> HttpResponse:
    t_a = (request.GET.get('a') or 'ABEV3').strip()
    t_b = (request.GET.get('b') or 'AERI3').strip()
    vals = (IndicatorValue.objects.select_related('indicator','company')
            .filter(company__ticker__in=[t_a, t_b])
            .order_by('indicator__group','indicator__label','company__ticker'))
    grouped = {}
    for iv in vals:
        key = (iv.indicator.group, iv.indicator.label, iv.indicator.code)
        grouped.setdefault(key, {'a': None, 'b': None, 'def': iv.indicator})
        if iv.company.ticker.upper() == t_a.upper():
            grouped[key]['a'] = iv
        elif iv.company.ticker.upper() == t_b.upper():
            grouped[key]['b'] = iv
    return render(request, 'fundamentus/hfm02_modal_compare.html', {
        'ticker_a': t_a.upper(), 'ticker_b': t_b.upper(), 'grouped': grouped
    })


def heatmap_dense_tooltip(request: HttpRequest) -> HttpResponse:
    q = (request.GET.get('q') or '').strip()
    klass = (request.GET.get('class') or '').strip()
    queryset = IndicatorValue.objects.select_related('indicator','company')
    if q:
        queryset = queryset.filter(
            models.Q(company__ticker__icontains=q) |
            models.Q(indicator__label__icontains=q) |
            models.Q(indicator__code__icontains=q)
        )
    if klass in dict(Classification.choices):
        queryset = queryset.filter(classification=klass)
    queryset = queryset.order_by('company__ticker','indicator__group','indicator__label')
    classes = [c[0] for c in Classification.choices]
    return render(request, 'fundamentus/hm03_dense_tooltip.html', {
        'values': queryset, 'q': q, 'klass': klass, 'classes': classes
    })


def heatmap_filter_sort(request: HttpRequest) -> HttpResponse:
    klass = (request.GET.get('class') or '').strip()
    sort = (request.GET.get('sort') or 'label').strip()
    order = (request.GET.get('order') or 'asc').strip()
    qs = IndicatorValue.objects.select_related('indicator','company')
    if klass in dict(Classification.choices):
        qs = qs.filter(classification=klass)
    if sort == 'ticker':
        order_by = 'company__ticker'
    elif sort == 'valor':
        order_by = 'value_raw'
    else:
        order_by = 'indicator__label'
    if order == 'desc':
        order_by = f'-{order_by}'
    qs = qs.order_by(order_by, 'indicator__group', 'company__ticker')
    return render(request, 'fundamentus/hm05_filter_sort.html', {
        'values': qs, 'klass': klass, 'sort': sort, 'order': order,
        'classes': [c[0] for c in Classification.choices]
    })


def detailed_table(request: HttpRequest) -> HttpResponse:
    raw = (request.GET.get('tickers') or '').strip()
    if raw:
        tickers = [t.strip().upper() for t in raw.split(',') if t.strip()]
    else:
        tickers = list(Company.objects.order_by('ticker').values_list('ticker', flat=True)[:2]) or ['ABEV3','AERI3']
    qs = (IndicatorValue.objects.select_related('indicator','company')
          .filter(company__ticker__in=tickers)
          .order_by('company__ticker','indicator__group','indicator__label'))
    values_by_ticker = defaultdict(list)
    for iv in qs:
        values_by_ticker[iv.company.ticker].append(iv)
    total_cards = qs.count()
    return render(request, 'fundamentus/v1_tabela.html', {
        'tickers': tickers, 'values_by_ticker': values_by_ticker, 'total_cards': total_cards
    })


def status_heatmap(request: HttpRequest) -> HttpResponse:
    raw = (request.GET.get('tickers') or '').strip()
    if raw:
        tickers = [t.strip().upper() for t in raw.split(',') if t.strip()]
    else:
        tickers = list(Company.objects.order_by('ticker').values_list('ticker', flat=True)[:2]) or ['ABEV3','AERI3']
    qs = (IndicatorValue.objects.select_related('indicator','company')
          .filter(company__ticker__in=tickers)
          .order_by('company__ticker','indicator__group','indicator__label'))
    heatmap = defaultdict(lambda: defaultdict(list))
    for iv in qs:
        heatmap[iv.company.ticker][iv.indicator.group].append(iv)
    return render(request, 'fundamentus/v2_heatmap.html', {
        'tickers': tickers, 'heatmap': heatmap
    })

# --- Nova visão ---

def minha_nova_visao(request: HttpRequest, ticker: str) -> HttpResponse:
    company = get_object_or_404(Company, ticker__iexact=ticker)
    values = (IndicatorValue.objects.select_related('indicator','company')
              .filter(company=company)
              .order_by('indicator__group','indicator__label'))
    return render(request, 'fundamentus/minha_nova_visao.html', {
        'company': company, 'values': values
    })
