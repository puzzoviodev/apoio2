from django.urls import path
from . import views

app_name = 'fundamentus'

urlpatterns = [
    path('', views.home, name='home'),
    path('overview/<str:ticker>/', views.overview, name='overview'),

    path('flip/<str:ticker>/', views.flip_cards_3d, name='flip'),
    path('heatmap/', views.filter_togglecard, name='heatmap'),
    path('quickstats/', views.quickstats, name='quickstats'),

    path('compare/', views.modal_compare, name='modal_compare'),
    path('heatmap/dense/', views.heatmap_dense_tooltip, name='heatmap_dense'),
    path('heatmap/smart/', views.heatmap_filter_sort, name='heatmap_filter_sort'),

    path('table/', views.detailed_table, name='detailed_table'),
    path('heatmap/status/', views.status_heatmap, name='status_heatmap'),

    path('minha-nova-visao/<str:ticker>/', views.minha_nova_visao, name='minha_nova_visao'),
]
