from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone

class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name='Company',
            fields=[('id', models.BigAutoField(primary_key=True, serialize=False, auto_created=True, verbose_name='ID')),
                    ('ticker', models.CharField(max_length=16, unique=True)),
                    ('name', models.CharField(max_length=128, blank=True, default=''))],
        ),
        migrations.CreateModel(
            name='IndicatorDefinition',
            fields=[('id', models.BigAutoField(primary_key=True, serialize=False, auto_created=True, verbose_name='ID')),
                    ('code', models.SlugField(max_length=64, unique=True)),
                    ('label', models.CharField(max_length=64)),
                    ('group', models.CharField(max_length=32, choices=[('Valuation','Valuation'),('Rentabilidade','Rentabilidade'),('Liquidez de Mercado','Liquidez de Mercado'),('Liquidez','Liquidez'),('Solvência','Solvência'),('Estrutura de Capital','Estrutura de Capital'),('Eficiência Operacional','Eficiência Operacional'),('Governança Corporativa','Governança Corporativa'),('Saúde Financeira','Saúde Financeira'),('Outros','Outros')], default='Outros')),
                    ('formula', models.TextField()),
                    ('definition', models.TextField()),
                    ('band', models.CharField(max_length=128, blank=True, default='')),
                    ('reference', models.CharField(max_length=128, blank=True, default=''))],
        ),
        migrations.CreateModel(
            name='IndicatorValue',
            fields=[('id', models.BigAutoField(primary_key=True, serialize=False, auto_created=True, verbose_name='ID')),
                    ('value_raw', models.DecimalField(max_digits=24, decimal_places=8, null=True, blank=True)),
                    ('value_display', models.CharField(max_length=64, blank=True, default='')),
                    ('classification', models.CharField(max_length=16, choices=[('Ótimo','Ótimo'),('Muito Bom','Muito Bom'),('Bom','Bom'),('Moderado','Moderado'),('Ruim','Ruim'),('Crítico','Crítico'),('Muito Crítico','Muito Crítico')])),
                    ('description', models.TextField(blank=True, default='')),
                    ('source', models.CharField(max_length=128, blank=True, default='StausInvest')),
                    ('updated_at', models.DateTimeField(default=django.utils.timezone.now)),
                    ('company', models.ForeignKey(to='fundamentus.company', on_delete=django.db.models.deletion.CASCADE, related_name='indicators')),
                    ('indicator', models.ForeignKey(to='fundamentus.indicatordefinition', on_delete=django.db.models.deletion.CASCADE, related_name='values'))],
            options={'unique_together': {('company','indicator')}},
        ),
    ]
