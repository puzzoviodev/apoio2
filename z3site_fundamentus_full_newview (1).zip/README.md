Z3 – Projeto Django completo + "Minha Nova Visão"
======================================================
Como rodar:
  python manage.py makemigrations
  python manage.py migrate
  python manage.py load_sample_metrics  # ou load_more_metrics
  python manage.py runserver

Entrar:
  /fundamentus/                  (Home)
  /fundamentus/overview/ABEV3/   (Overview com links)
  /fundamentus/minha-nova-visao/ABEV3/
